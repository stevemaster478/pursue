<?php 
require_once("config.php");
if((isset($_POST['nome'])&& $_POST['nome'] !='') && (isset($_POST['mail'])&& $_POST['mail'] !=''))
{
 require_once("contact_mail.php");
    $nome = $conn->real_escape_string($_POST['nome']);
    $mail = $conn->real_escape_string($_POST['your_email']);
    $content = $conn->real_escape_string($_POST['content']);
    $sql = "INSERT INTO contact_form_info (nome, mail, content) VALUES ('" . $nome . "','" . $mail . "', '" . $content . "')";
    if (!$result = $conn->query($sql)) {
        die("C'è stato un problema nella query [' . $conn->error . ']");
    } else {
        echo "Grazie! Ti contatteremo presto";
    }
} else {
    echo "Per favore inserisci correttamente il nome e la mail";
}
?>