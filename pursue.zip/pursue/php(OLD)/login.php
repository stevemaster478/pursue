<?php

require_once('config.php');

$email = stripslashes($_POST['email']);
$email = mysqli_real_escape_string($con, $email);
$password = stripslashes($_POST['password']);
$password = mysqli_real_escape_string($con, $password);

if ($_SERVER["REQUEST_METHOD"] === "POST"){
    $sql_select= "SELECT * FROM utente WHERE email = '$email'";
    $result = mysqli_query($con, $sql_select) or die;
    if($result->num_rows == 1){
        $row = $result->fetch_array(MYSQLI_ASSOC);
        if(password_verify($password, $row['pass'])){
            session_start();

            $_SESSION['loggato'] = true;
            $_SESSION['id'] = $row['id'];
            $_SESSION['email'] = $row['email'];

            header("location: ../courses.html");
        }else{
            echo "La password non è corretta";
            echo "<br>";
        }
    }else{
        echo "Non ci sono account con quella mail";
        echo "<br>";
    }
}else{
    echo "Errore in fase di login";
    echo "<br>";
}

$con -> close();

?>