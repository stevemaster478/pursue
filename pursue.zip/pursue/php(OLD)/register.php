<?php

require_once('config.php');

$email = $con->real_escape_string($_POST['regemail']);
$password = $con->real_escape_string($_POST['regpassword']);

//$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO utente (email, pass) VALUES ('$email', '$password');";
if ($con -> query($sql)) {
    echo "Registrazione effettuata con successo";
}else {
    echo "Errore durante la tua registrazione $sql. " . $con->error;
}
$con -> close();
?>