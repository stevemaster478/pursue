let questions = [
    {
    numb: 1,
    question: "Quale tra questi processori ha il socket LGA 2066??",
    answer: "i7-7740 x",
    options: [
      "i7-7740 x",
      "i7-3770 f",
      "ryzen 9 5950",
      "ryzen 5 5600"
    ]
  },
    {
    numb: 2,
    question: "Quale tra questi processori ha più di 25 MB di cache??",
    answer: "i7-12700",
    options: [
      "ryzen 5 3600",
      "i7-12700",
      "ryzen 5 5600",
      "ryzen 3 3300"
    ]
  },
    {
    numb: 3,
    question: "Quale tra questi processori ha più di 150 watt di potenza??",
    answer: "i9-12900 KS",
    options: [
      "i9-12900 KS",
      "i7-3770 f",
      "ryzen 5 5600",
      "ryzen 3 3300"
    ]
  },
    {
    numb: 4,
    question: "Qual è la differenza tra un alimentatore modulare e uno non??",
    answer: "il non modulare ha attacchi statici e quindi non rimovibili, dunque è più ingombrante",
    options: [
      "la differenza sta nell’elettricità data ai componenti, il modulare da meno potenza",
      "il non modulare ha attacchi statici e quindi non rimovibili, dunque è più ingombrante",
      "la differenza sta nell’elettricità data ai componenti, il modulare da più potenza",
      "la differenza sta all’esterno, il modulare non conduce "
    ]
  },
    {
    numb: 5,
    question: "Quale tra queste schede madri non supporta i 3200 MHz di ram??",
    answer: "Biostar TB360-BTC",
    options: [
      "Asrock H310CM-DVS",
      "GIGABYTE GA-H310M-H",
      "Biostar TB360-BTC",
      "msi b450"
    ]
  },
  {
    numb: 6,
    question: "Quanta ram serve per avviare Microsoft Flight simulator??",
    answer: "8gb",
    options: [
      "4gb",
      "8gb",
      "16gb",
      "32gb"
    ]
  },
  {
    numb: 7,
    question: "Qual è la differenza tra VRAM e NVRAM??",
    answer: "una è non volatile, l’altra è volatile",
    options: [
      "una è non volatile, l’altra è volatile",
      "vram è meno potente della nvram",
      "non ci sono differenze",
      "esistono entrambe e sono dentro alla ram del pc, la differenza è vram non è utilizzata"
    ]
  },
  {
    numb: 8,
    question: "Per una configurazione con: I9 11900k, 32gb ram, 3080 ti, z590 quale PSU serve per farla funzionare correttamente??",
    answer: "800w",
    options: [
      "500w",
      "600w",
      "700w",
      "800w"
    ]
  },
  {
    numb: 9,
    question: "Che differenza c'è tra un' alimentatore Bronze, Silver, Gold e Platinum??",
    answer: "la differenza è la qualità della PSU",
    options: [
      "la differenza è il tipo di ‘scheletro’",
      "la differenza è la qualità della PSU",
      "la differenza è il tipo di potenza",
      "la differenza è la marca"
    ]
  },
  {
    numb: 10,
    question: "Qual è il vantaggio delle RAM DDR5? E perchè sono meglio delle precedenti DDR4??",
    answer: "sono molto più veloci, ma costano molto di più e non sono ancora in commercio",
    options: [
      "sono molto più veloci, ma costano molto di più e non sono ancora in commercio",
      "sono molto più veloci e costano anche di meno",
      "sono più lente, però costano di meno e sono più reperibili",
      "sono più resistenti e sono anche impermeabili"
    ]
  },
  {
    numb: 11,
    question: "Che funzione ha il V-SYNC??",
    answer: "aiuta la sincronizza lo schermo con la gpu per non far sfarfallare le immagini",
    options: [
      "aiuta la visualizzazione dello schermo mettendo in risalto le parti meno luminose",
      "aiuta la sincronizzazione tra le parti mancanti di un gioco e la ram",
      "aiuta la sincronizza lo schermo con la gpu per non far sfarfallare le immagini",
      "aiuta a sincronizzare il secondo schermo con il primo"
    ]
  },
    {
    numb: 12,
    question: "Che differenza ce tra freeSync e G-sync?",
    answer: "la differenza è che una è di invidia, l’altra è di amd",
    options: [
      "la differenza è il tipo di sincronizzazione ",
      "la differenza è che una è di invidia, l’altra è di amd",
      "la differenza è che una è libera, l’altra è incatenata",
      "non ci sono differenze, sono utilizzabili entrambe allo stesso tempo"
    ]
  },
    {
    numb: 13,
    question: "Quali tra questi switch sono più veloci??",
    answer: "rossi ",
    options: [
      "verdi ",
      "blu",
      "rossi",
      "marroni"
    ]
  },
    {
    numb: 14,
    question: "Che differenza c’è tra un monitor LCD e Amoled??",
    answer: "la differenza sta nel tipo di pannello, gli LCD sono retroilluminati invece negli amoled i pixel si illuminano da soli",
    options: [
      "la differenza è il costo, non cambia molto se non la marca del monitor",
      "la differenza è la luminosità, Amoled è più luminoso",
      "la differenza è il consumo di corrente, Amoled consuma di più",
      "la differenza sta nel tipo di pannello, gli LCD sono retroilluminati invece negli amoled i pixel si illuminano da soli"
    ]
  },
    {
    numb: 15,
    question: "Che funzioni hanno i MINI-LED della nuova gamma di Samsung??",
    answer: "la funzione dei MINI-LED è aumentare il numero di pixel effettivi del monitor",
    options: [
      "la funzione dei MINI-LED è aumentare il numero di pixel effettivi del monitor",
      "la funzione dei MINI-LED è diminuire la potenza richiesta del monitor",
      "la funzione dei MINI-LED è aumentare la precisione del monitor",
      "la funzione dei MINI-LED è diminuire la risoluzione del monitor"
    ]
  }
];