let questions = [
    {
    numb: 1,
    question: "Che cosa vuol dire 'ROM'?",
    answer: "read only memory",
    options: [
      "read only memory",
      "regularly only memory",
      "recovery only memory",
      "reload only memory"
    ]
  },
    {
    numb: 2,
    question: "Come funziona un mouse moderno?",
    answer: "funziona con un lettore ottico",
    options: [
      "funziona con una palla ",
      "funziona con un lettore ottico",
      "funziona con un laser",
      "funziona tramite lo sfregamento del tessuto"
    ]
  },
    {
    numb: 3,
    question: "Quali tra questi non è un dispositivo di input?",
    answer: "monitor",
    options: [
      "tastiera",
      "mouse",
      "monitor",
      "videocamera"
    ]
  },
    {
    numb: 4,
    question: "Quali tra questi non è un dispositivo di output?",
    answer: "microfono",
    options: [
      "cassa",
      "monitor",
      "microfono",
      "stampante"
    ]
  },
    {
    numb: 5,
    question: "Che cos’è il case?",
    answer: "un contenitore di ferro e/o di vetro contenente i componenti del pc",
    options: [
      "una scatola",
      "un contenitore di ferro e/o di vetro contenente i componenti del pc",
      "un contenitore esclusivamente di ferro contenente i componenti del pc",
      "il processore"
    ]
  },
  {
    numb: 6,
    question: "Cosa deve aver un computer per leggere un disco?",
    answer: "il masterizzatore",
    options: [
      "basta il mouse",
      "la webcam",
      "presa usb",
      "il masterizzatore"
    ]
  },
  {
    numb: 7,
    question: "Perchè se colleghi le cuffie all’AUX non funziona il microfono?",
    answer: "perchè le cuffie sono collegate in output e non in input",
    options: [
      "perchè il microfono delle cuffie è rotto",
      "perchè le cuffie non sono della stessa marca del pc",
      "perchè la porta aux ha problemi",
      "perchè le cuffie sono collegate in output e non in input"
    ]
  },
  {
    numb: 8,
    question: "Qual è la differenza tra tastiera a membrana e meccanica?",
    answer: "discreta differenza tattile e in velocità di risposta",
    options: [
      "nessuna differenza",
      "leggera differenza solo tattile",
      "discreta differenza tattile e in velocità di risposta",
      "enorme differenza in tutto"
    ]
  },
  {
    numb: 9,
    question: "Che vantaggi ha una tastiera meccanica?",
    answer: "può avere vantaggi in campo gaming, per la sua velocità di risposta",
    options: [
      "può essere di vantaggio a chi scrive, per il rumore dei suoi tasti",
      "può avere vantaggi in campo gaming, per la sua velocità di risposta",
      "costa di meno",
      "sono le più rare e quindi hanno un costo maggiore nel rivenderle"
    ]
  },
  {
    numb: 10,
    question: "Che vantaggi ha una tastiera a membrana?",
    answer: "può avere vantaggi in campo gaming, per la sua velocità di risposta",
    options: [
      "può essere di vantaggio a chi scrive,  per la leggerezza dei tasti",
      "può avere vantaggi in campo gaming, per la sua velocità di risposta",
      "costa di meno",
      "sono le più rare e quindi hanno un costo maggiore nel rivenderle"
    ]
  },
    {
    numb: 11,
    question: "Come si chiamano i “puntini” sotto il processore??",
    answer: "pin",
    options: [
      "puntini",
      "points",
      "pin",
      "pip"
    ]
  },
    {
    numb: 12,
    question: "Di quali materiali è fatta la scheda madre??",
    answer: "fibra di vetro e resina artificiale collante",
    options: [
      "fibra di vetro e resina artificiale collante",
      "solo rame",
      "rame e silicio",
      "silicio oro zinco rame e vetro"
    ]
  },
    {
    numb: 13,
    question: "Di che materiale è fatto il processore??",
    answer: "silicio",
    options: [
      "rame",
      "silicio",
      "oro",
      "argento"
    ]
  },
    {
    numb: 14,
    question: "Che cosa sono i DPI di un mouse??",
    answer: "la velocità del cursore",
    options: [
      "la densità della grandezza di un mouse misurata in pollici",
      "la densità del suo cursore",
      "la grandezza del mouse comparabile alla mano umana",
      "la velocità del cursore"
    ]
  },
  {
    numb: 15,
    question: "Quale funzione hanno le ventole del pc?",
    answer: "ad avere un buon airflow così da non surriscaldare i componenti",
    options: [
      "a raffreddare il processore",
      "ad avere un buon airflow così da non surriscaldare i componenti",
      "a mantenere sempre la temperatura costante",
      "ad abbellire il pc"
    ]
  }
];