let questions = [
    {
    numb: 1,
    question: "Qual è il componente più costoso di un PC da gaming??",
    answer: "gpu",
    options: [
      "psu",
      "ram",
      "ssd",
      "gpu"
    ]
  },
  {
    numb: 2,
    question: "Che cos’è il profilo XMP??",
    answer: "è una tecnologia usata dalle schede madri per aumentare la frequenza delle ram",
    options: [
      "è una tecnologia usata dalle schede madri per aumentare la frequenza delle ram",
      "è un profilo che si fanno i professionisti quando resettano il bios",
      "è un profilo integrato del pc che si può accedere solo dall’esterno",
      "è una tecnologia usata per aggiornare il bios"
    ]
  },
  {
    numb: 3,
    question: "Quanto costa  un masterizzatore CD??",
    answer: "20",
    options: [
      "5",
      "20",
      "50 ",
      "100"
    ]
  },
  {
    numb: 4,
    question: "Quali tra queste CPU è più costose??",
    answer: "ryzen 7 3800x",
    options: [
      "i3 9100 f",
      "ryzen 7 3800x",
      "i7 3770 f",
      "ryzen 5 5600 g"
    ]
  },
  {
    numb: 5,
    question: "Quali tra queste GPU è più costose??",
    answer: "gtx 1080ti",
    options: [
      "gtx 1030",
      "rtx 2060",
      "rx 5500xt",
      "gtx 1080ti"
    ]
  },
  {
    numb: 6,
    question: "Qual è la differenza tra AMD ed NVIDIA?",
    answer: "sono due marche differenti, una sviluppa solo gpu, l’altro anche cpu",
    options: [
      "sono due marche differenti, una sviluppa solo gpu, l’altro anche cpu",
      "sono due componenti diversi",
      "sono due marche di componenti, una sempre inferiore all’altra",
      "sono due marche completamente uguali, annettendosi"
    ]
  },
    {
    numb: 7,
    question: "cosa vuol dire rgb? ?",
    answer: "sono i colori dei led rosso verde blu",
    options: [
      "sono i colori dei led rosso verde blu ",
      "è un componente del pc",
      "è una parte essenziale del processore",
      "non vuol dire nulla"
    ]
  },
    {
    numb: 8,
    question: "Che differenza c’è tra multi-core e single core??",
    answer: "la differenza è che il processo è svolto da un solo core e non da tanti ",
    options: [
      "la differenza è che il processo è svolto da un solo core e non da tanti ",
      "la differenza sta nel tipo di processore",
      "la differenza sta nel tipo di applicazione",
      "la differenza sta nella scelta della scheda madre, a seconda di essa, i processi si muovono"
    ]
  },
    {
    numb: 9,
    question: "Quali tra questi processori costa di meno??",
    answer: "i7 3770 f",
    options: [
      "i3 9100 f",
      "ryzen 7 3800x",
      "i7 3770 f",
      "ryzen 5 5600 g"
    ]
  },
    {
    numb: 10,
    question: "A cosa serve il silicio??",
    answer: "serve per i processori",
    options: [
      "serve per le schede madri",
      "serve per i processori",
      "serve per le ram",
      "serve per gli ssd"
    ]
  },
  {
    numb: 11,
    question: "Da dove prendono il silicio le grandi aziende??",
    answer: "Hypeanguage",
    options: [
      "alaska",
      "polo nord",
      "africa",
      "russia"
    ]
  },
  {
    numb: 12,
    question: "Come mai le schede video sono il componente più costoso??",
    answer: "le gpu sono costose perché sono il componente più ricercato e quindi viene richiesta più potenza in essa",
    options: [
      "le gpu sono costose perché sono il componente più ricercato e quindi viene richiesta più potenza in essa",
      "le gpu sono costose perché sono essenziali per far funzionare il pc",
      "le gpu sono costose perché hanno componenti costosi",
      "le gpu sono costose perché vengono utilizzate dai miner"
    ]
  },
  {
    numb: 13,
    question: "Perché ora le grandi aziende sono a corto di Chip (2020)??",
    answer: "perchè per la pandemia le grandi aziende stavano fallendo e non potevano pagare i lavoratori",
    options: [
      "perchè  per la pandemia i chip erano esplosivi",
      "perchè  per la pandemia le grandi aziende erano a corto di altri componenti",
      "perchè per la pandemia le grandi aziende stavano fallendo e non potevano pagare i lavoratori",
      "perchè per la pandemia ci sono state delle interruzioni delle macchine"
    ]
  },
  {
    numb: 14,
    question: "Perché è importante una buona ventilazione??",
    answer: "perchè c’è il rischio di continui crash del pc",
    options: [
      "perché altrimenti il computer potrebbe fondersi",
      "perché altrimenti i componenti potrebbero bruciarsi",
      "perchè c’è il rischio di continui crash del pc",
      "perchè il pc potrebbe risentirne con il tempo"
    ]
  },
  {
    numb: 15,
    question: "Che differenza c’è tra i dissipatori AIO e quelli ad aria??",
    answer: "Hypeguage",
    options: [
      "la differenza sta nella potenza, quelli AIO sono meno potenti",
      "la differenza sta nella durata",
      "la differenza sta nel costo",
      "la differenza sta nel rumore e nella potenza, a vantaggio di quelli AIO"
    ]
  }
];