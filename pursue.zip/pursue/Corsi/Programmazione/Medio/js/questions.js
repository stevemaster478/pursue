// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Come si stampa una stringa su Java?",
    answer: "Con la funzione System.out.println",
    options: [
      "Con la funzione printf()",
      "Con la funzione System.out.println",
      "Con la funzione scanf()",
      "Con la funzione while()"
    ]
  },
    {
    numb: 2,
      question: "Quali parentesi si usano per la dichiarazione di un vettore in C?",
      answer: "Quadre",
    options: [
      "Quadre",
      "Tonde",
      "Graffe",
      "Non si usano"
    ]
  },
    {
    numb: 3,
      question: "Come si dichiara una funzione in JavaScript?",
      answer: "function nome(argomenti) {// istruzioni}",
    options: [
      "function nome(argomenti) {// istruzioni}",
      "function argomenti(nome) {//istruzioni}",
      "function argomenti(nome) [//istruzioni]",
      "function nome(argomenti) [//istruzioni]"
    ]
  },
    {
    numb: 4,
      question: "Che cos'e' la classe 'Object' su Java?",
      answer: "E' la superclasse",
    options: [
      "E' una classe di programmazione ad oggetti",
      "E' una classe del main",
      "E' una sottoclasse",
      "E' la superclasse"
    ]
  },
    {
    numb: 5,
      question: "Che cosa sono i canvas su java?",
      answer: "Una semplice superficie di disegno utile alle operazioni grafiche",
    options: [
      "Una semplice superficie di disegno utile alle operazioni grafiche",
      "Sono le query di risposta",
      "Sono diapositive di Java",
      "L'insieme dei metodi di un programma"
    ]
  },
  {
    numb: 6,
    question: "Che cosa sono i vettori paralleli?",
    answer: "Un gruppo di array dove gli elementi nella stessa posizione costituiscono un insieme di dati correlati",
    options: [
      "Sono due vettori che fungono da puntatori",
      "Sono due vettori sommati insieme",
      "Un gruppo di array dove gli elementi nella stessa posizione costituiscono un insieme di dati correlati",
      "Non esistono in ambito informatico"
    ]
  },
  {
    numb: 7,
    question: "Qual e' la differenza tra 'public' e 'private' in Java?",
    answer: "Il 'private'? utilizzato per le classi e 'public' per le superclassi",
    options: [
      "Il 'public' rende i file pubblici a tutto il dominio e la privata rende questi privati e visualizzabili solo dall'utente che gli ha creati",
      "Il 'public' ? utilizzato per le classi e 'private' per le superclassi",
      "Il 'private' ? utilizzato per le classi e 'public' per le superclassi",
      "Non ci sono differenze"
    ]
  },
  {
    numb: 8,
    question: "Cos'e' il legame dinamico in Java?",
    answer: "Un legame  dinamico si realizza tra la chiamata al metodo e la sua funzione associata durante l'esecuzione del programma",
    options: [
      "Un legame  dinamico si realizza tra la chiamata al metodo e la sua funzione associata durante l'esecuzione del programma",
      "Un legame tra due vettori",
      "Un legame tra vettore e puntatore",
      "Un legame tra due piattaforme in contemporanea"
    ]
  },
  {
    numb: 9,
    question: "Come si traduce il 'finche'' in C?",
    answer: "Si traduce con do while()",
    options: [
      "Si traduce con do while()",
      "Si traduce con il for()",
      "Si traduce con il printf()",
      "Non esiste il comando in C"
    ]
  },
  {
    numb: 10,
    question: "Quale tra questi non e' un ciclo 'for' corretto in C?",
    answer: "for(i=0;i<10;i++){printf('inserisci il %d numero: ', i+1);scanf('%d', &n);}",
    options: [
      "for (<inizializzazione>; <condizione>; <espressione_iterativa>) {// istruzioni}",
      "int acc = 0; for (int i = 0; i < 100; i += 2){acc ...",
      "for(i=0;i<10;i++){printf('inserisci il %d numero: ', i+1);scanf('%d', &n);}",
      "for(i=0;i<10;i++){printf('inserisci il %d numero: ', i+1);"
    ]
  },
  {
    numb: 11,
    question: "Che cos'e' una funzione 'void' in C?",
    answer: "E' una funzione che non restituisce un valore di ritorno",
    options: [
      "E' una funzione che non restituisce un valore di ritorno",
      "E' una funzione che contiene puntatori",
      "E' una funzione privata",
      "E' una funzione che restituisce un valore di ritorno"
    ]
  },
  {
    numb: 12,
    question: "Che cos'e' una webstring.h?",
    answer: "E' una libreria",
    options: [
      "E' una libreria",
      "E' un'estensione dell'IDE",
      "E' una stringa della Superclasse",
      "E' una stringa di una superclasse"
    ]
  },
  {
    numb: 13,
    question: "Come si crea una tabella in SQL?",
    answer: "Con il comando 'create Table name(//attributi)'",
    options: [
      "Con il comando 'create table(//attributi)'",
      "Con il comando 'create table(//attributi):' ",
      "Con il comando 'create Table name(//attributi):'",
      "Con il comando 'create Table name(//attributi)'"
    ]
  },
  {
    numb: 14,
    question: "Che cosa fa il comando 'select' in SQL?",
    answer: "Permette di fare le interrogazioni al database",
    options: [
      "Permette di selezionare il database'",
      "Permette di fare le interrogazioni al database",
      "Permette di selezionare gli attributi",
      "Permette di aggiornare i campi gia scritti di una tabella"
    ]
  },
  {
    numb: 15,
    question: "Di quale linguaggio appartiene il comando 'echo'?",
    answer: "PHP",
    options: [
      "PHP",
      "CSS",
      "HTML",
      "SQL"
    ]
  },
];