// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Quale comando tra questi e' sbagliato?",
    answer: "System.out.printf;",
    options: [
      "System.out.println();",
      "System.out.print();",
      "System.out.printf;",
      "System.out.println('Ciao'); "
    ]
  },
    {
    numb: 2,
      question: "Quali tra questi comandi addEventListener e' sbagliato?",
      answer: "filedocument.getElementById('tooltip-link1').addEventListener('click', function(){ displayTooltip(2) });",
    options: [
      "filedocument.getElementById('tooltip-link1').addEventListener('click', function(){ displayTooltip(2) });",
      "document.addEventListener('mousemove', testo);function testo() {  document.getElementById('code').innerHTML='Coding Creativo';} </script>",
      "document.addEventListener('mouseover', casuale); function casuale() {document.getElementById('numero')",
      "document.getElementById('tooltip-link1').addEventListener('click', function(){ displayTooltip(2) });"
    ]
  },
    {
    numb: 3,
      question: "Quali tra queste funzioni non implementa niente?",
      answer: "function somma() {var z = 13;} var risultato = risultato();",
    options: [
      "document.getElementById('tooltip-link1').addEventListener('click', function(){ displayTooltip(2) });",
      "function somma(x, y) {var z = x + y;return z;}",
      "function somma() {var z = 0;var i;for (i in arguments) {z = z + arguments[i];}return z;}",
      "function somma() {var z = 13;} var risultato = risultato();"
    ]
  },
    {
    numb: 4,
      question: "Quale tra questi comandi non e' un comando Java?",
      answer: "Doctype.java",
    options: [
      "Clear",
      "Debug",
      "Doctype.java",
      "Assert"
    ]
  },
    {
    numb: 5,
      question: "Cosa serve il comando 'integer'?",
      answer: "Serve per tutti i numeri interi",
    options: [
      "Serve per tutti i numeri interi",
      "Serve solo per numeri piccoli interi nel quale si conoscono gia' in anticipo",
      "Serve per copiare una variabile  in due diversi linguaggi di programmazione",
      "Serve per usufruire delle librerie"
    ]
  },
  {
    numb: 6,
    question: "Cosa serve il comando position relative in HTML?",
    answer: "Va' a modificare la posizione naturale di un elemento traslandola",
    options: [
      "Va' a modificare la posizione naturale di un elemento traslandola",
      "Modifica la posizione degli elementi",
      "Modifica i parametri delle tabelle",
      "Va' a modificare l'indirizzo del documento cha abbiamo salvato"
    ]
  },
  {
    numb: 7,
    question: "Cosa serve la manipolazione dei buffer in C?",
    answer: "Serve a scrivere dati direttamente in memoria o ogni volta che vuoi manipolare i dati archiviati nella memoria non gestita",
    options: [
      "Serve a scrivere dati direttamente in memoria o ogni volta che vuoi manipolare i dati archiviati nella memoria non gestita",
      "Non serve",
      "Serve a scrivere dati direttamente in variabili o ogni volta che vuoi manipolare i dati archiviati nella memoria gestita",
      "Serve per dichiarare i vettori"
    ]
  },
  {
    numb: 8,
    question: "A che cosa serve l'utilizzo di 'pipe()' in C?",
    answer: "Crea una coppia di file descriptor, utilizzabili per una 'pipe'",
    options: [
      "Crea una coppia di file descriptor, utilizzabili per una 'pipe'",
      "Crea un vettore utilizzabile per una 'pipe'",
      "Crea un puntatore utilizzabile per una 'pipe'",
      "E' scritto in modo errato, quindi non funziona"
    ]
  },
  {
    numb: 9,
    question: "Cosa sono le classi wrapper in Java?",
    answer: "Sono le corrispondenti di una classe primitiva",
    options: [
      "Sono classi che interagiscono con altre tramite una relazione",
      "Sono semplici superclassi",
      "Sono le corrispondenti di una classe primitiva",
      "Sono semplici sottoclassi"
    ]
  },
  {
    numb: 10,
    question: "A che cosa serve la libreria Tensor Flow?",
    answer: "Importa comandi python in macchine che non ne hanno gia' installati",
    options: [
      "Importa i file e li apre come file Python",
      "Serve per mappare il nostro file",
      "Serve per mappare e modificare file senza autorizzazioni",
      "Importa comandi python in macchine che non ne hanno gia' installati"
    ]
  },
  {
    numb: 11,
    question: "A che cosa serve la libreria cv2 in python",
    answer: "Fornisce moduli sperimentati e ottimizzati, per realizzare  algoritmi per diversi tipi di compiti percettivi e di comprensione del linguaggio",
    options: [
      "Per importare comandi utili al calcolo delle variabili",
      "Fornisce moduli utili per i diagrammi",
      "Fornisce moduli sperimentati e ottimizzati, per realizzare  algoritmi per diversi tipi di compiti percettivi e di comprensione del linguaggio",
      "Non e' una libreria"
    ]
  },
  {
    numb: 12,
    question: "Le differenze tra struct e union in C",
    answer: "Union e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi mentre Structure e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi",
    options: [
      "Structure e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi mentre Union e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi",
      "Union e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi mentre Structure e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi",
      "Struct viene usato in C mentre Union viene usato in Python",
      "Union viene usato per la tipologia di attributo mentre Struct per stampare la variabile"
    ]
  },
  {
    numb: 13,
    question: "Perche' usare la funzione system()? Cosa cambia dal mettere solo return 0?",
    answer: "return 0 fa parte della libreria standard di C, percio' non serve utilizzare una funzione derivata da stdlib.h come system() per freezare la bash di Windows",
    options: [
      "return 0 non restituisce errore percio' non lascia 'freezato' il pc, mentre system() si'",
      "return 0 restituisce errore percio' non lascia 'freezato' il pc, mentre system() si'",
      "system() non restituisce errore percio' lascia 'freezato' il pc, mentre return 0 si'",
      "return 0 fa parte della libreria standard di C, percio' non serve utilizzare una funzione derivata da stdlib.h come system() per freezare la bash di Windows"
    ]
  },
  {
    numb: 14,
    question: "Quali tra questi linguaggi non e' di programmazione?",
    answer: "HTML",
    options: [
      "HTML",
      "JavaScript",
      "Java",
      "Assembly"
    ]
  },
  {
    numb: 15,
    question: "Cosa serve per poter avviare Java nella macchina?",
    answer: "Java Runtime Environment",
    options: [
      "Oracle VirtualBox",
      "VMWare",
      "Java Runtime Environment",
      "Java Virtual Machine"
    ]
  },
];