// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Che significa l'acronimo CSS?",
    answer: "Cascading Style Sheets",
    options: [
      "Ciphertext  Style  Sheets",
      "Cascading Style Sheets",
      "Cascading Sheets Style",
      "Ciphertext Sheets Style"
    ]
  },
    {
    numb: 2,
      question: "Che significa l'acronimo HTML?",
      answer: "HyperText Markup Language",
    options: [
      "HyperText Markup Language",
      "High Text Markup level",
      "High Text Markup Language",
      "HyperText Markup Level"
    ]
  },
    {
    numb: 3,
      question: "Che significa l'acronimo JS?",
      answer: "JavaScript",
    options: [
      "JavaSolid",
      "JSON",
      "Java Structured",
      "JavaScript"
    ]
  },
    {
    numb: 4,
      question: "Che significa l'acronimo SQL?",
    answer: "Structured Query Language",
    options: [
      "Stylish Question Language",
      "Stylesheet Query Language",
      "Statement Question Language",
      "Structured Query Language"
    ]
  },
    {
    numb: 5,
      question: "La differenza tra SQL e mySQL",
      answer: "SQL e' il linguaggio per database basati sul modello relazionale mentre mySQL e' il DBMS",
    options: [
      "Non ci sono differenze",
      "SQL e' un linguaggio di programmazione e  mySQL e' un estensione",
      "Sono due linguaggi standardizzati per database diversi",
      "SQL e' il linguaggio per database basati sul modello relazionale mentre mySQL e' il DBMS"
    ]
  },
  {
    numb: 6,
    question: "Che cos'e' una Query string?",
    answer: "E' la parte di un URL che contiene dei dati da passare in input ad una variabile",
    options: [
      "E' una normale stringa scritta in SQL",
      "E' la parte di un URL che contiene dei dati da passare in input ad una variabile",
      "E' un messaggio di errore nella compilazione",
      "E'una stringa con all'interno un messaggio"
    ]
  },
  {
    numb: 7,
    question: "Cos'e' un puntatore?",
    answer: "E' una variabile che contiene l'indirizzo di memoria",
    options: [
      "E' un tipo di  dati campionati all'interno di un messaggio",
      "E' una variabile che contiene l'indirizzo di memoria",
      "E' un vettore informatico",
      "E' un elemento del diagramma ER"
    ]
  },
  {
    numb: 8,
    question: "Differenze tra GET e POST",
    answer: "Nel metodo GET i dati sono scritti direttamente all'interno dell'URL mentre nel metodo POST i parametri URL sono nella richiesta HTTP",
    options: [
      "Non ci sono differenze",
      "Il metodo GET viene usato in PHP e il metodo POST viene usato in HTML",
      "Nel metodo GET i dati sono scritti direttamente all'interno dell'URL mentre nel metodo POST i parametri URL sono nella richiesta HTTP",
      "Nel metodo POST  i dati sono scritti direttamente all'interno dell'URL mentre nel metodo POST i parametri URL sono  nella richiesta HTTP"
    ]
  },
  {
    numb: 9,
    question: "In quali campi viene utilizzato Python?",
    answer: "Viene utilizzato anche nella programmazione ad oggetti",
    options: [
      "Viene utilizzato solo nella programmazione ad oggetti ",
      "Viene utilizzato anche nella programmazione ad oggetti",
      "Non viene utilizzato nei dispositivi IOS",
      "Non viene utilizzato nel lato dinamico delle pagine"
    ]
  },
  {
    numb: 10,
    question: "Che cos'e' Dev-C++?",
    answer: "Un IDE",
    options: [
      "Un linguaggio di programmazione",
      "Un IDE",
      "Una libreria del linguaggio C",
      "Un editor di testo"
    ]
  },
  {
    numb: 11,
    question: "Che cos'e' un IDE?",
    answer: "Un ambiente software",
    options: [
      "Un linguaggio di programmazione",
      "Una guida informatica",
      "Le impostazioni del editor",
      "Un ambiente software"
    ]
  },
  {
    numb: 12,
    question: "La differenza tra un IDE ed un editor di testo?",
    answer: "L'IDE e' un ambiente software per creare e testare il software mentre l'editor di testo e' un programma utilizzato per la modifica del testo",
    options: [
      "L'IDE e' un ambiente software per creare e testare il software mentre l'editor di testo e' un programma utilizzato per la modifica del testo",
      "L'Editor di testo e' un ambiente software per creare e testare il software mentre l'IDE e' un programma utilizzato per la modifica del testo",
      "Sono sinonimi",
      "Non ci sono differenze"
    ]
  },
  {
    numb: 13,
    question: "Cosa fa il comando 'printf()' in C?",
    answer: "Stampa una stringa",
    options: [
      "Effettua un ciclo FOR",
      "Stampa una stringa",
      "Inserisce un vettore",
      "Inserisce un puntatore"
    ]
  },
  {
    numb: 14,
    question: "Come si conclude un comando in C?",
    answer: "Con ';'",
    options: [
      "Con ';'",
      "Con ':'",
      "Con '.'",
      "Con ')'"
    ]
  },
  {
    numb: 15,
    question: "Che cos'e' una libreria?",
    answer: "E' un insieme di funzioni",
    options: [
      "E'un estensione di un determinato linguaggio",
      "E' una piattaforma nel quale ci sono tutti i linguaggi di compilazione",
      "E' un insieme di funzioni",
      "E' il percorso per il salvataggio dei file"
    ]
  },
];