INSERT INTO corso (tipo) VALUES
("Programmazione"),
("Sicurezza"),
("Cloud"),
("Internet Of Things"),
("Intelligenza Artificiale"),
("Hardware"),
("Basi del computer"),
("Cultura dell'informatica");

INSERT INTO difficolta (diff) VALUES
("Facile"),
("Medio"),
("Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Che significa l’acronimo CSS?","Programmazione","Facile"),
("Che significa l’acronimo HTML?","Programmazione","Facile"),
("Che significa l’acronimo JS?","Programmazione","Facile"),
("Che significa l’acronimo SQL?","Programmazione","Facile"),
("La differenza tra SQL e mySQL","Programmazione","Facile"),
("Che cos’e' una Query string?","Programmazione","Facile"),
("Cos’e' un puntatore?","Programmazione","Facile"),
("Differenze tra GET e POST","Programmazione","Facile"),
("In quali campi viene utilizzato Python?","Programmazione", "Facile"),
("Che cos’e' Dev-C++?","Programmazione","Facile"),
("Che cos’e' un IDE?","Programmazione","Facile"),
("La differenza tra un IDE ed un editor di testo?","Programmazione","Facile"),
("Cosa fa il comando 'printf()' in C?","Programmazione","Facile"),
("Come si conclude un comando in C?","Programmazione","Facile"),
("Che cos’e' una libreria?","Programmazione","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Come si stampa una stringa su Java?","Programmazione","Medio"),
("Quali parentesi si usano per la dichiarazione di un vettore in C?","Programmazione","Medio"),
("Come si dichiara una funzione in JavaScript?","Programmazione","Medio"),
("Che cos’e' la classe 'Object' su Java?","Programmazione","Medio"),
("Che cosa sono i canvas su Java?","Programmazione","Medio"),
("Che cosa sono i vettori paralleli?","Programmazione","Medio"),
("Qual e' la differenza tra 'public' e 'private' in Java?","Programmazione","Medio"),
("Cos’e' il legame dinamico in Java?","Programmazione","Medio"),
("Come si traduce il 'finche''  in C?","Programmazione","Medio"),
("Quale tra questi non e' un ciclo 'for' corretto in C?","Programmazione","Medio"),
("Che cos’e' una funzione 'void' in C?","Programmazione","Medio"),
("Che cos’e' una webstring.h?","Programmazione","Medio"),
("Come si crea una tabella in SQL?","Programmazione","Medio"),
("Che cosa fa il comando 'select' in SQL?","Programmazione","Medio"),
("Di quale linguaggio appartiene il comando 'echo'?","Programmazione","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Quale comando tra questi e' sbagliato?","Programmazione","Difficile"),
("Quali tra questi comandi addEventListener e' sbagliato?","Programmazione","Difficile"),
("Quali tra queste funzioni non implementa niente?","Programmazione","Difficile"),
("Quale tra questi comandi non e' un comando java?","Programmazione","Difficile"),
("Cosa serve il comando 'integer'?","Programmazione","Difficile"),
("Cosa serve il comando position relative in HTML?","Programmazione","Difficile"),
("Cosa serve la manipolazione dei buffer in C?","Programmazione","Difficile"),
("A che cosa serve l'utilizzo di 'pipe()' in C?","Programmazione","Difficile"),
("Cosa sono le classi wrapper in Java?","Programmazione","Difficile"),
("A che cosa serve la libreria cv2 in python","Programmazione","Difficile"),
("A che cosa serve la libreria Tensor Flow?","Programmazione","Difficile"),
("Le differenze tra struct e union in C","Programmazione","Difficile"),
("Perche' usare la funzione system()? Cosa cambia dal mettere solo return 0?","Programmazione","Difficile"),
("Quali tra questi linguaggi non e' di programmazione?","Programmazione","Difficile"),
("Cosa serve per poter avviare Java nella macchina?","Programmazione","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("A cosa serve la modalita' incognito?","Sicurezza","Facile"),
("Che cos’e' un antivirus?","Sicurezza","Facile"),
("Che cos’e' una VPN?","Sicurezza","Facile"),
("Che cos’e' un firewall?","Sicurezza","Facile"),
("Che cosa si intende per 'fishing'?","Sicurezza","Facile"),
("Che cosa si intende per 'spamming'?","Sicurezza","Facile"),
("Quali tra queste distribuzioni ha come base d’utilizzo una serie di programmi orientati al pentesting?","Sicurezza","Facile"),
("Cos’e' il pentesting e perche' e' importante?","Sicurezza","Facile"),
("Chi e' Kevin Mitnick?","Sicurezza","Facile"),
("Differenza tra client e server?","Sicurezza","Facile"),
("Quale tra queste architetture di rete viene utilizzata per le reti torrent?","Sicurezza","Facile"),
("Cosa significa CCcam?","Sicurezza","Facile"),
("Perche' non conviene utilizzare una tecnologia senza fili (Bluetooth, Wi-Fi, NFC…)?","Sicurezza","Facile"),
("Il Jammer e' utile per…","Sicurezza","Facile"),
("Cos’e' 'SQL Injection'?","Sicurezza","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("A cosa viene utilizzato il Port Mapping?","Sicurezza","Medio"),
("Quali tra questi software e' utile per lo sniffing?","Sicurezza","Medio"),
("Cos’e' un exploit in sicurezza informatica?","Sicurezza","Medio"),
("Quali sono gli strumenti per fare pentesting in locale tra questi?","Sicurezza","Medio"),
("Esiste anche un sito per fare pentesting, come si chiama?","Sicurezza","Medio"),
("In cosa consiste il Social Engineering?","Sicurezza","Medio"),
("In cosa consiste il Man in the Middle?","Sicurezza","Medio"),
("Quali tra questi attacchi e' utilizzato per indovinare le password?","Sicurezza","Medio"),
("Quali tra questi protocolli e' consigliato utilizzare nella propria rete?","Sicurezza","Medio"),
("Cos’e' la Rubber Ducky?","Sicurezza","Medio"),
("Cos’e' l’ALFA Network?","Sicurezza","Medio"),
("Differenza tra Trojan, Virus, Ransomware, Worm","Sicurezza","Medio"),
("Quali sono i gradi di malware?","Sicurezza","Medio"),
("In cosa consiste l’USB Killer?","Sicurezza","Medio"),
("Cos’e' il Denial of Service? Qual e' la differenza tra Denial of Service e Distributed Denial of Service?","Sicurezza","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Cos’e' il defacing di una pagina web?","Sicurezza","Difficile"),
("Chi e' uno degli autori di Parrot OS?","Sicurezza","Difficile"),
("Cos’e' un payload?","Sicurezza","Difficile"),
("In cosa consiste il tunneling con SOCKS?","Sicurezza","Difficile"),
("In cosa consiste il tunneling con SSH?","Sicurezza","Difficile"),
("In cosa consiste l’attacco watering hole?","Sicurezza","Difficile"),
("In cosa consiste il pharming?","Sicurezza","Difficile"),
("In cosa consiste il farmjacking?","Sicurezza","Difficile"),
("In cosa consiste il smishing?","Sicurezza","Difficile"),
("Cos’e' Advanced Persistent Threat?","Sicurezza","Difficile"),
("Qual e' la differenza tra IPTV e CCCAM?","Sicurezza","Difficile"),
("Come si effettua un MAC Spoofing?","Sicurezza","Difficile"),
("A cosa serve una backdoor?","Sicurezza","Difficile"),
("A cosa serve il progetto Cloud_enum?","Sicurezza","Difficile"),
("Quale tool tra questi viene utilizzato per fare Password Spraying?","Sicurezza","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Cos’e' il cloud computing?","Cloud","Facile"),
("Quanti sono i principali servizi di cloud?","Cloud","Facile"),
("Quali sono i principali tipi di cloud?","Cloud","Facile"),
("Quali servizi offre un cloud?","Cloud","Facile"),
("In quali ambiti viene usato un cloud?","Cloud","Facile"),
("Quali sono le differenze tra cloud ibrido e privato?","Cloud","Facile"),
("Quali sono le differenze tra cloud privato e pubblico?","Cloud","Facile"),
("Su quali dispositivi si puo' utilizzare un cloud?","Cloud","Facile"),
("Il cloud e' disponibile offline?","Cloud","Facile"),
("Che differenze ci sono tra cloud?","Cloud","Facile"),
("Cos’e' la  'cloud security'?","Cloud","Facile"),
("Quali tipi di dati si possono salvare su un cloud?","Cloud","Facile"),
("Dove trovo il Cloud?","Cloud","Facile"),
("Come viene definito l’ambiente o l’architettura del cloud?","Cloud","Facile"),
("Da cosa deriva il nome 'cloud'?","Cloud","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Cos’e' Hive?","Cloud","Medio"),
("Quali sono i 3 principali vantaggi del cloud computing?","Cloud","Medio"),
("Cosa serve per utilizzare il cloud computing?","Cloud","Medio"),
("Come funziona mega?","Cloud","Medio"),
("Cos’e' un data center?","Cloud","Medio"),
("Qual e'  il principale data center di Apple?","Cloud","Medio"),
("Cos’e' l’'infrastructure as a service'?","Cloud","Medio"),
("Cos’e' il 'platform as a service'?","Cloud","Medio"),
("Cos’e' il 'software as a service'?","Cloud","Medio"),
("Come viene anche chiamato il 'platform as a service'?","Cloud","Medio"),
("Cos’e' il cloud privato?","Cloud","Medio"),
("Cos’e' il cloud pubblico?","Cloud","Medio"),
("Cos’e' il cloud ibrido?","Cloud","Medio"),
("Cos’e' il multi-cloud?","Cloud","Medio"),
("A cosa serve Cloudera?","Cloud","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Quali tra questi servizi non usa un'infrastruttura cloud?","Cloud","Difficile"),
("Dove vengono salvati fisicamente i dati che si trovano su un cloud?","Cloud","Difficile"),
("Cosa sono 'sistemi on-premise'?","Cloud","Difficile"),
("Quali sono i livelli di funzionamento dell’infrastruttura IaaS?","Cloud","Difficile"),
("Su quale architettura si appoggia l’Azure di Microsoft?","Cloud","Difficile"),
("Quali sono i livelli di funzionamento dell’infrastruttura PaaS?","Cloud","Difficile"),
("Quali sono i livelli di funzionamento dell’infrastruttura SaaS?","Cloud","Difficile"),
("Che differenza c’e' tra Mainframe e Cloud?","Cloud","Difficile"),
("Cosa sono i server dedicati?","Cloud","Difficile"),
("Pro e contro tra Cloud-based e In-House servers?","Cloud","Difficile"),
("Cos’e' una VPS?","Cloud","Difficile"),
("Cos’e' una 'cloud migration'?","Cloud","Difficile"),
("Cos’e' 'hadoop'?","Cloud","Difficile"),
("Cos'e' il CSP?","Cloud","Difficile"),
("Differenze tra Cloudera e Spark","Cloud","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Dov’e' non e' stata implementata la tecnologia Bluetooth?","Internet of Things","Facile"),
("Cosa si intende per Internet of Things?","Internet of Things","Facile"),
("Cos’e' Arduino?","Internet of Things","Facile"),
("Cos’e' Raspberry Pi?","Internet of Things","Facile"),
("Cos’e' il sonar?","Internet of Things","Facile"),
("Di cosa si tratta la smart-city?","Internet of Things","Facile"),
("Di cosa si tratta la smart-grid","Internet of Things","Facile"),
("Quale tra questi ambienti non viene utilizzata l’IoT?","Internet of Things","Facile"),
("Quali tra questi sono esempi di sicurezza domotica?","Internet of Things","Facile"),
("Indica tra questi esempi le funzioni di impianto elettrico intelligente","Internet of Things","Facile"),
("Indica tra questi esempi le funzioni di impianto climatizzazione intelligente","Internet of Things","Facile"),
("Indica tra questi esempi le funzioni di impianto automazione intelligente","Internet of Things","Facile"),
("Cosa si intende per Smart Agriculture?","Internet of Things","Facile"),
("Cos’e' Moocall?","Internet of Things","Facile"),
("Cos’e' il Wireless Sensor Network?","Internet of Things","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("A cosa serve 'RFID' nell’IoT?","Internet of Things","Medio"),
("Quale tra queste definizioni fa riferimento al 'Vehicle-To-Everything'?","Internet of Things","Medio"),
("Cos’e' il Bluelink della Hyundai?","Internet of Things","Medio"),
("Cos’e' il Virtual Cockpit?","Internet of Things","Medio"),
("Qual e' il significato dell’acronimo 'ADAS'?","Internet of Things","Medio"),
("Cos’e' il digital twin?","Internet of Things","Medio"),
("Di cosa si tratta il Machine2Machine?","Internet of Things","Medio"),
("Cos’e' lo SCADA?","Internet of Things","Medio"),
("Che architettura hardware e software utilizza Arduino?","Internet of Things","Medio"),
("Tra queste opzioni c’e' un’azienda che si occupa del settore sanitario con l’uso dell’IoT, qual e'?","Internet of Things","Medio"),
("Quali sono le caratteristiche della smart-city?","Internet of Things","Medio"),
("A cosa servono le smart-city?","Internet of Things","Medio"),
("Quali delle citta' ha implementato le smart-city?","Internet of Things","Medio"),
("Che problemi si potrebbero riscontrare nell’IoT?","Internet of Things","Medio"),
("Quali sono i vantaggi dell’applicazione dell’IoT nella medicina?","Internet of Things","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Come funziona una smart card?","Internet of Things","Difficile"),
("Cos’e' l’edge computing e come viene applicata la tecnologia dell’IoT in quell’ambito?","Internet of Things","Difficile"),
("Come funziona il movimento dei droni?","Internet of Things","Difficile"),
("Cos’e' il Red Hat OpenShift?","Internet of Things","Difficile"),
("Cosa significa dell’IIoT?","Internet of Things","Difficile"),
("Come funziona l’automazione dell’IIoT?","Internet of Things","Difficile"),
("Cosa Industry 4.0?","Internet of Things","Difficile"),
("La quarta rivoluzione industriale?","Internet of Things","Difficile"),
("Come funziona feed-forward?","Internet of Things","Difficile"),
("Cosa tratta la rete neurale spiking?","Internet of Things","Difficile"),
("Quali tra questi e' un modello di rete neurale artificiale?","Internet of Things","Difficile"),
("Quale tra questi e' un algoritmo di rete neurale a base radiale?","Internet of Things","Difficile"),
("Quale algoritmo tra questi viene utilizzato per lo spam filtering?","Internet of Things","Difficile"),
("Quale tra queste tecnologie bisognerebbe utilizzare per il riconoscimento vocale?","Internet of Things","Difficile"),
("Cos’e' AlphaZero?","Internet of Things","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Che cos’e' un intelligenza artificiale?","Intelligenza Artificiale","Facile"),
("Che cos’e' un assistente vocale?","Intelligenza Artificiale","Facile"),
("Che cosa puo' fare un assistente vocale?","Intelligenza Artificiale","Facile"),
("Quanti livelli ha l'intelligenza artificiale?","Intelligenza Artificiale","Facile"),
("Quali sono i due tipi di IA?","Intelligenza Artificiale","Facile"),
("Quali sono i sottoinsiemi dell’intelligenza artificiale tra queste risposte?","Intelligenza Artificiale","Facile"),
("Chi ha coniato il termine intelligenza artificiale?","Intelligenza Artificiale","Facile"),
("Cosa si intende per intelligenza artificiale forte?","Intelligenza Artificiale","Facile"),
("In che decennio nacque l'Intelligenza Artificiale?","Intelligenza Artificiale","Facile"),
("Quali sono gli svantaggi dell'intelligenza artificiale?","Intelligenza Artificiale","Facile"),
("In che settori viene utilizzata oggi l'intelligenza artificiale?","Intelligenza Artificiale","Facile"),
("Che cosa si intende per deep learning?","Intelligenza Artificiale","Facile"),
("Che cosa si intende per back-propagation?","Intelligenza Artificiale","Facile"),
("La robotica e' direttamente associata all'intelligenza artificiale?","Intelligenza Artificiale","Facile"),
("Indica l’ordine di funzionamento dell’intelligenza artificiale","Intelligenza Artificiale","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("In cosa consiste il principio di Asilomar?","Intelligenza Artificiale","Medio"),
("In cosa consiste la macchina di Turing?","Intelligenza Artificiale","Medio"),
("Cos’e' il grid computing?","Intelligenza Artificiale","Medio"),
("Perche' si parla di IA-completo?","Intelligenza Artificiale","Medio"),
("Cos’e' Watson?","Intelligenza Artificiale","Medio"),
("Qual e' il nome dell’intelligenza artificiale utilizzata dalla Tesla per l’autoguida?","Intelligenza Artificiale","Medio"),
("Quando nacque e dove nacque l’intelligenza artificiale?","Intelligenza Artificiale","Medio"),
("Chi e' il padre dell’intelligenza artificiale?","Intelligenza Artificiale","Medio"),
("In cosa consiste la Rete neurale artificiale?","Intelligenza Artificiale","Medio"),
("In cosa consiste Deep Blue?","Intelligenza Artificiale","Medio"),
("In cosa consiste Google DeepMind?","Intelligenza Artificiale","Medio"),
("Cosa tratta l’algoritmo genetico?","Intelligenza Artificiale","Medio"),
("Differenza tra Machine Learning, Deep Learning e Intelligenza Artificiale?","Intelligenza Artificiale","Medio"),
("Cosa tratta l’algoritmo evolutivo?","Intelligenza Artificiale","Medio"),
("In cosa si tratta la neuroevoluzione?","Intelligenza Artificiale","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("In cosa consiste 'Black-Box AI'?","Intelligenza Artificiale","Difficile"),
("Cos’e' Acovea?","Intelligenza Artificiale","Difficile"),
("In cosa consiste Particle Swarm Optimization?","Intelligenza Artificiale","Difficile"),
("Cos’e' il concetto di crossover dell'algoritmo genetico?","Intelligenza Artificiale","Difficile"),
("Come funziona l’Auto-Pilot di Tesla?","Intelligenza Artificiale","Difficile"),
("Cos’e' l’EDLUT?","Intelligenza Artificiale","Difficile"),
("Come funziona l’EDLUT?","Intelligenza Artificiale","Difficile"),
("Come funziona feed-forward?","Intelligenza Artificiale","Difficile"),
("Cosa tratta la rete neurale spiking?","Intelligenza Artificiale","Difficile"),
("Quali tra questi e' un modello di rete neurale artificiale?","Intelligenza Artificiale","Difficile"),
("Quale tra questi e' un algoritmo di rete neurale a base radiale?","Intelligenza Artificiale","Difficile"),
("Quale algoritmo tra questi viene utilizzato per lo spam filtering?","Intelligenza Artificiale","Difficile"),
("Quale tra queste tecnologie bisognerebbe utilizzare per il riconoscimento vocale?","Intelligenza Artificiale","Difficile"),
("Quali tra questi algoritmi si utilizza per la traduzione o language translation?","Intelligenza Artificiale","Difficile"),
("Cos’e' AlphaZero?","Intelligenza Artificiale","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Che cos’e' la ROM?","Hardware","Facile"),
("Come funziona un mouse?","Hardware","Facile"),
("Quali tra questi non e' un dispositivo di input?","Hardware","Facile"),
("Quali tra questi non e' un dispositivo di output?","Hardware","Facile"),
("Che cos’e' il case?","Hardware","Facile"),
("Cosa deve aver un computer per leggere un disco?","Hardware","Facile"),
("Perche' se colleghi le cuffie all’AUX non funziona il microfono?","Hardware","Facile"),
("Qual e' la differenza tra tastiera a membrana e meccanica?","Hardware","Facile"),
("Che vantaggi ha una tastiera meccanica?","Hardware","Facile"),
("Che vantaggi ha una tastiera a membrana?","Hardware","Facile"),
("Come si chiamano i 'puntini' sotto il processore?","Hardware","Facile"),
("Di quali materiali e' fatta la scheda madre?","Hardware","Facile"),
("Di che materiale e' fatto il processore?","Hardware","Facile"),
("Che cosa sono i DPI di un mouse?","Hardware","Facile"),
("Quale funzione hanno le ventole del pc?","Hardware","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Qual e' il componente piu' costoso di un PC da gaming?","Hardware","Medio"),
("Che cos’e' il profilo XMP?","Hardware","Medio"),
("Quanto costa  un masterizzatore CD?","Hardware","Medio"),
("Quali tra queste CPU e' piu' costose?","Hardware","Medio"),
("Quali tra queste GPU e' piu' costose?","Hardware","Medio"),
("Qual e' la differenza tra AMD ed NVIDIA?","Hardware","Medio"),
("Cosa vuol dire rgb?","Hardware","Medio"),
("Che differenza c’e' tra multi-core e single core?","Hardware","Medio"),
("Quali tra questi processori girano meglio in multi-core?","Hardware","Medio"),
("A cosa serve il silicio?","Hardware","Medio"),
("Da dove prendono il silicio le grandi aziende?","Hardware","Medio"),
("Come mai le schede video sono il componente più costoso?","Hardware","Medio"),
("Perche' ora le grandi aziende sono a corto di Chip?","Hardware","Medio"),
("Perche' e' importante una buona ventilazione?","Hardware","Medio"),
("Che differenza c’e' tra i dissipatori AIO e quelli ad aria?","Hardware","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Quale tra questi processori ha il socket LGA 2066?","Hardware","Difficile"),
("Quale tra questi processori ha piu' di 25 MB di cache?","Hardware","Difficile"),
("Quale tra questi processori ha piu' di 150 watt di potenza?","Hardware","Difficile"),
("Qual e' la differenza tra un alimentatore modulare e uno non?","Hardware","Difficile"),
("Quale tra queste schede madri non supporta i 3200 MHz di ram?","Hardware","Difficile"),
("Quanta ram serve per avviare Microsoft Flight simulator?","Hardware","Difficile"),
("Qual e' la differenza tra VRAM e NVRAM?","Hardware","Difficile"),
("Per una configurazione con: I9 11900k, 32gb ram, 3080 ti, z590 quale PSU serve per farla funzionare correttamente?","Hardware","Difficile"),
("Che differenza c'e' tra una PSU Bronze, Silver, Gold e Platinum?","Hardware","Difficile"),
("Qual e' il vantaggio delle RAM DDR5? E perche' sono meglio delle precedenti DDR4?","Hardware","Difficile"),
("Che funzione ha il V-SYNC?","Hardware","Difficile"),
("Che differenza ce tra freeSync e G-sync?","Hardware","Difficile"),
("Quali tra questi switch sono piu' veloci?","Hardware","Difficile"),
("Che differenza c’e' tra un monitor LCD e Amoled?","Hardware","Difficile"),
("Che funzioni hanno i MINI-LED della nuova gamma di Samsung?","Hardware","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Come si usa la funzione 'copia' da tastiera?","Basi del Computer","Facile"),
("Come si usa la funzione 'incolla' da tastiera?","Basi del Computer","Facile"),
("Che cos’e' un’icona?","Basi del Computer","Facile"),
("Che cos’e' piu' grande?","Basi del Computer","Facile"),
("Come si possono trasferire immagini da telefono a pc?","Basi del Computer","Facile"),
("A cosa serve il tasto Windows?","Basi del Computer","Facile"),
("Come si scrive il carattere 'e''?","Basi del Computer","Facile"),
("Come si stampa un file?","Basi del Computer","Facile"),
("Che cos’e' una 'scorciatoia da tastiera'?","Basi del Computer","Facile"),
("Cosa succede se metti un programma nel cestino?","Basi del Computer","Facile"),
("Che proprieta' ha il formato PDF?","Basi del Computer","Facile"),
("Che significa il formato txt?","Basi del Computer","Facile"),
("Che significa il formato ppt?","Basi del Computer","Facile"),
("Quale tra i seguenti dispositivi di memoria ha la capacita' piu' alta?","Basi del Computer","Facile"),
("Come si fa ad installare Windows su una macchina appena montata?","Basi del Computer","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Che cos’e' una macchina virtuale?","Basi del Computer","Medio"),
("Che differenza c'e' tra HTTP e HTTPS?","Basi del Computer","Medio"),
("Dove si usa il protocollo HTTP?","Basi del Computer","Medio"),
("Che cos’e' un collegamento ipertestuale?","Basi del Computer","Medio"),
("Quanto e' grande uno Yottabyte (in byte)?","Basi del Computer","Medio"),
("Che cosa fa il kernel?","Basi del Computer","Medio"),
("Cos’e' un hypervisor?","Basi del Computer","Medio"),
("Cosa si intende per 'struttura ad albero' in ambito di salvataggio dati?","Basi del Computer","Medio"),
("Quanti caratteri diversi possono essere rappresentati con il codice ASCII?","Basi del Computer","Medio"),
("Dove sono contenuti i dati che vanno persi quando si spegne il pc?","Basi del Computer","Medio"),
("Che funzione svolge la ALU?","Basi del Computer","Medio"),
("Che cosa si intende per 'linguaggio ad alto livello'?","Basi del Computer","Medio"),
("Cosa sono i registri di sistema?","Basi del Computer","Medio"),
("Qual e' la caratteristica principale di un programma open source?","Basi del Computer","Medio"),
("Cosa sono i Java Applets?","Basi del Computer","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Come si ripristina la password irrecuperabile del BIOS / UEFI nei computer?","Basi del Computer","Difficile"),
("Per cosa sta l’acronimo RDP?","Basi del Computer","Difficile"),
("Cos’e' un settore di un hard disk?","Basi del Computer","Difficile"),
("Qual e' l’utilizzo dell’OU in Active Directory?","Basi del Computer","Difficile"),
("Per cosa sta l’acronimo MDM?","Basi del Computer","Difficile"),
("IEEE 1394 e' conosciuto anche come?","Basi del Computer","Difficile"),
("Differenza tra Telnet e SSH?","Basi del Computer","Difficile"),
("A cosa sono legati il CUDA e il PhysX?","Basi del Computer","Difficile"),
("Cosa sono GNOME e KDE?","Basi del Computer","Difficile"),
("Quale tra queste non e' un VMM?","Basi del Computer","Difficile"),
("Cos’e' il Blue Screen of Death?","Basi del Computer","Difficile"),
("Qual e' il nome del processo che ha come valore PID 1 in Linux?","Basi del Computer","Difficile"),
("Qual e' l’output di un input con valori 1,1 con 2 nella porta logica XOR?","Basi del Computer","Difficile"),
("Quale tra questi nomi di processi avvia le impostazioni del ODBC?","Basi del Computer","Difficile"),
("Quale tra queste non e' un Version Control System?","Basi del Computer","Difficile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Chi e' il fondatore di Google?","Cultura dell'Informatica","Facile"),
("Cosa significa PCI?","Cultura dell'Informatica","Facile"),
("Cos’e' WannaCry?","Cultura dell'Informatica","Facile"),
("Cos’e' Jigsaw?","Cultura dell'Informatica","Facile"),
("Chi e' il co-fondatore della Apple?","Cultura dell'Informatica","Facile"),
("Chi e' Sean Parker?","Cultura dell'Informatica","Facile"),
("Cos’e' CryptoLocker?","Cultura dell'Informatica","Facile"),
("Cos’e' Bitcoin?","Cultura dell'Informatica","Facile"),
("Cos’e' una Blockchain?","Cultura dell'Informatica","Facile"),
("Cos’e' il kernel?","Cultura dell'Informatica","Facile"),
("Perche' e' importante il SEO?","Cultura dell'Informatica","Facile"),
("Per quale motivo venne progettato il layout delle tastiere QWERTY? Qual e' il beneficio?","Cultura dell'Informatica","Facile"),
("Qual e' il nome precedente di Java?","Cultura dell'Informatica","Facile"),
("Chi invento' il primo computer?","Cultura dell'Informatica","Facile"),
("Chi sono i padri del kernel GNU/Linux?","Cultura dell'Informatica","Facile");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Per cosa si usa Citrix?","Cultura dell'Informatica","Medio"),
("Cosa significa COBOL?","Cultura dell'Informatica","Medio"),
("Che cos’e' un chipset?","Cultura dell'Informatica","Medio"),
("Da dove potresti mappare un'unita' di rete in windows?","Cultura dell'Informatica","Medio"),
("Cosa significa O in CMOS?","Cultura dell'Informatica","Medio"),
("Quale azienda non ha mai prodotto pc?","Cultura dell'Informatica","Medio"),
("Nella gestione dei computer windows a cosa serve ODBC?","Cultura dell'Informatica","Medio"),
("Cosa viene usato per suddividere i valori in un file csv?","Cultura dell'Informatica","Medio"),
("Cos’e' il DMA?","Cultura dell'Informatica","Medio"),
("A cosa serve il DHCP?","Cultura dell'Informatica","Medio"),
("Per  cosa viene usato il firewire?","Cultura dell'Informatica","Medio"),
("In C++ per cosa e' usato il simbolo '!='?","Cultura dell'Informatica","Medio"),
("Quale dei seguenti non e' un linguaggio di programmazione?","Cultura dell'Informatica","Medio"),
("Cos’e' un settore disco su un disco rigido?","Cultura dell'Informatica","Medio"),
("Cosa significa SONET?","Cultura dell'Informatica","Medio");

INSERT INTO domanda (domanda,fk_corso,difficoltaDomanda) VALUES
("Cosa apparirebbe se digitassi 'cal' in linux bash?","Cultura dell'Informatica","Difficile"),
("Qual e' il primo dei seguenti sistemi operativi che supporta nativamente il comando TRIM per le unita' SATA allo stato solido?","Cultura dell'Informatica","Difficile"),
("Qual e' la differenza tra gli hypervisor di tipo 1 e 2?","Cultura dell'Informatica","Difficile"),
("A cosa serve il comando 'cp' in linux bash?","Cultura dell'Informatica","Difficile"),
("Quale delle seguenti funzioni ha una funzione smagnetizzante?","Cultura dell'Informatica","Difficile"),
("Qual e' la causa piu' probabile di un overflow dello stack?","Cultura dell'Informatica","Difficile"),
("Quali sono le architetture del kernel GNU/Linux?","Cultura dell'Informatica","Difficile"),
("Su quale kernel sono basati GNU/Linux, macOS, Windows e altri?","Cultura dell'Informatica","Difficile"),
("Quali sono le shell piu' utilizzate nelle architetture basate sul kernel GNU/Linux?","Cultura dell'Informatica","Difficile"),
("Per cosa venne sviluppato originalmente FORTRAN?","Cultura dell'Informatica","Difficile"),
("Converti 1011B (binario) in esadecimale.","Cultura dell'Informatica","Difficile"),
("Quale tipo di struttura dati e' una queue?","Cultura dell'Informatica","Difficile"),
("Quale tra questi non e' un software per il web server?","Cultura dell'Informatica","Difficile"),
("Per cosa sta la D nell’acronimo CIDR?","Cultura dell'Informatica","Difficile"),
("Quale tra queste e' un Distributed Version Control System?","Cultura dell'Informatica","Difficile");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("1","0", "Ciphertext  Style  Sheets", "Programmazione", "Facile"),
("1", "1", "Cascading Style Sheets", "Programmazione", "Facile"),
("1","0", "Cascading Sheets Style", "Programmazione", "Facile"),
("1", "0", "Ciphertext Sheets Style", "Programmazione", "Facile"),

("2","1", "HyperText Markup Language", "Programmazione", "Facile"),
("2", "0", "High Text Markup level", "Programmazione", "Facile"),
("2","0", "High Text Markup Language", "Programmazione", "Facile"),
("2", "0", "HyperText Markup Level", "Programmazione", "Facile"),

("3","0", "JavaSolid", "Programmazione", "Facile"),
("3", "0", "JSON", "Programmazione", "Facile"),
("3","0", "Java Structured", "Programmazione", "Facile"),
("3", "1", "JavaScript", "Programmazione", "Facile"),

("4","1", "Structured Query Language", "Programmazione", "Facile"),
("4", "0", "Style Query Language", "Programmazione", "Facile"),
("4","0", "Structured Query Line", "Programmazione", "Facile"),
("4", "0", "System Query Language", "Programmazione", "Facile"),

("5","0", "Non ci sono differenze ", "Programmazione", "Facile"),
("5", "0", "SQL e' un linguaggio di programmazione e  mySQL e' un estensione", "Programmazione", "Facile"),
("5","0", "Sono due linguaggi standardizzati per database diversi", "Programmazione", "Facile"),
("5", "1", "SQL è il linguaggio per database basati sul modello relazionale mentre mySQL e' il DBMS", "Programmazione", "Facile"),

("6","0", "E' una normale stringa  scritta in SQL", "Programmazione", "Facile"),
("6", "1", "E' la parte di un URL che contiene dei dati da passare in input ad una variabile", "Programmazione", "Facile"),
("6","0", "E' un messaggio di errore nella compilazione", "Programmazione", "Facile"),
("6", "0", "E'una stringa con all’interno un messaggio", "Programmazione", "Facile"),

("7","1", "E' una variabile che contiene l'indirizzo di memoria", "Programmazione", "Facile"),
("7", "0", "E' un tipo di  dati campionati all’interno di un messaggio", "Programmazione", "Facile"),
("7","0", "E' un vettore informatico", "Programmazione", "Facile"),
("7", "0", "E' un elemento del diagramma ER", "Programmazione", "Facile"),

("8","0", "Non ci sono differenze ", "Programmazione", "Facile"),
("8", "0", "Il metodo GET viene usato in PHP e il metodo POST viene usato in HTML", "Programmazione", "Facile"),
("8","1", "Nel metodo GET i dati sono scritti direttamente all’interno dell’URL mentre nel metodo POST i parametri URL sono nella richiesta HTTP", "Programmazione", "Facile"),
("8", "0", "Nel metodo POST  i dati sono scritti direttamente all’interno dell’URL mentre nel metodo POST i parametri URL sono  nella richiesta HTTP", "Programmazione", "Facile"),

("9","0", "Viene utilizzato solo nella programmazione ad oggetti ", "Programmazione", "Facile"),
("9", "1", "Viene utilizzato anche nella programmazione ad oggetti", "Programmazione", "Facile"),
("9","0", "Non viene utilizzato nei dispositivi IOS", "Programmazione", "Facile"),
("9", "0", "Non viene utilizzato nel lato dinamico delle pagine", "Programmazione", "Facile"),

("10","0", "Un linguaggio di programmazione", "Programmazione", "Facile"),
("10", "1", "Un IDE", "Programmazione", "Facile"),
("10","0", "Una libreria del linguaggio C", "Programmazione", "Facile"),
("10", "0", "Un editor di testo", "Programmazione", "Facile"),

("11","0", "Un linguaggio di programmazione", "Programmazione", "Facile"),
("11", "0", "Una guida informatica", "Programmazione", "Facile"),
("11","0", "Le impostazioni del editor", "Programmazione", "Facile"),
("11", "1", "Un ambiente software", "Programmazione", "Facile"),

("12","1", "L’IDE e' un ambiente software per creare e testare il software mentre l’editor di testo e' un programma utilizzato per la modifica del testo", "Programmazione", "Facile"),
("12", "0", "L'Editor di testo e' un ambiente software per creare e testare il software mentre l’IDE e' un programma utilizzato per la modifica del testo", "Programmazione", "Facile"),
("12","0", "Sono sinonimi", "Programmazione", "Facile"),
("12", "0", "Non ci sono differenze", "Programmazione", "Facile"),

("13","0", "Effettua un ciclo FOR", "Programmazione", "Facile"),
("13", "1", "Stampa una stringa", "Programmazione", "Facile"),
("13","0", "Inserisce un vettore", "Programmazione", "Facile"),
("13", "0", "Inserisce un puntatore", "Programmazione", "Facile"),

("14","1", "Con ';'", "Programmazione", "Facile"),
("14", "0", "Con ':'", "Programmazione", "Facile"),
("14","0", "Con '.'", "Programmazione", "Facile"),
("14", "0", "Con ')'", "Programmazione", "Facile"),

("15","0", "E'un estensione di un determinato linguaggio", "Programmazione", "Facile"),
("15", "0", "E' una piattaforma nel quale ci sono tutti i linguaggi di compilazione", "Programmazione", "Facile"),
("15","1", "E' un insieme di funzioni", "Programmazione", "Facile"),
("15", "0", "E' il percorso per il salvataggio dei file", "Programmazione", "Facile");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("16","0", "Con la funzione printf", "Programmazione", "Medio"),
("16", "1", "Con la funzione System.out.println", "Programmazione", "Medio"),
("16","0", "Con la funzione scanf", "Programmazione", "Medio"),
("16", "0", "Con la funzione while", "Programmazione", "Medio"),

("17","1", "Quadre", "Programmazione", "Medio"),
("17", "0", "Tonde", "Programmazione", "Medio"),
("17","0", "Graffe", "Programmazione", "Medio"),
("17", "0", "Non si usano", "Programmazione", "Medio"),

("18","1", "function nome(argomenti) {// istruzioni}", "Programmazione", "Medio"),
("18", "0", "function argomenti(nome) {//istruzioni}", "Programmazione", "Medio"),
("18","0", "function argomenti(nome) [//istruzioni]", "Programmazione", "Medio"),
("18", "0", "function nome(argomenti) [//istruzioni]", "Programmazione", "Medio"),

("19","1", "E' la superclasse", "Programmazione", "Medio"),
("19", "0", "E' una classe di programmazione ad oggetti", "Programmazione", "Medio"),
("19","0", "E' una classe del main", "Programmazione", "Medio"),
("19", "0", "E' una sottoclasse", "Programmazione", "Medio"),

("20","1", "Una semplice superficie di disegno utile alle operazioni grafiche", "Programmazione", "Medio"),
("20", "0", "Sono le query di risposta", "Programmazione", "Medio"),
("20","0", "Sono diapositive di java", "Programmazione", "Medio"),
("20", "0", "L'insieme dei metodi di un programma", "Programmazione", "Medio"),

("21","0", "Sono due vettori che fungono da puntatori", "Programmazione", "Medio"),
("21", "0", "Sono  due  vettori  sommati insieme", "Programmazione", "Medio"),
("21","1", "Un gruppo di array dove gli elementi nella stessa posizione costituiscono un insieme di dati correlati", "Programmazione", "Medio"),
("21", "0", "Non esistono in ambito informatico", "Programmazione", "Medio"),

("22","0", "Il 'public' rende i file pubblici a tutto il dominio e la privata rende questi privati e visualizzabili solo dall’utente che gli ha creati", "Programmazione", "Medio"),
("22", "0", "Il 'public' è utilizzato per le classi e 'private' per le superclassi", "Programmazione", "Medio"),
("22","1", "Il 'private' è utilizzato per le classi e 'public' per le superclassi", "Programmazione", "Medio"),
("22", "0", "Non ci sono differenze", "Programmazione", "Medio"),

("23","1", "Un legame  dinamico si realizza tra la chiamata al metodo e la sua funzione associata durante l’esecuzione del programma", "Programmazione", "Medio"),
("23", "0", "Un legame tra due vettori", "Programmazione", "Medio"),
("23","0", "Un legame tra vettore e puntatore", "Programmazione", "Medio"),
("23", "0", "Un legame tra due piattaforme in contemporanea", "Programmazione", "Medio"),

("24","1", "Si traduce con do while", "Programmazione", "Medio"),
("24", "0", "Si traduce con il for", "Programmazione", "Medio"),
("24","0", "Si traduce con il printf ", "Programmazione", "Medio"),
("24", "0", "Non esiste il comando in C", "Programmazione", "Medio"),

("25","0", "for (<inizializzazione>; <condizione>; <espressione_iterativa>) {// istruzioni}", "Programmazione", "Medio"),
("25", "0", "int acc = 0; for (int i = 0; i < 100; i += 2){acc += i;}", "Programmazione", "Medio"),
("25","1", "for(i=0;i<10;i++){printf('inserisci il %d numero: ', i+1);scanf('%d', &n);}", "Programmazione", "Medio"),
("25", "0", "for(i=0;i<10;i++){printf('inserisci il %d numero: ', i+1);", "Programmazione", "Medio"),

("26","1", "E' una funzione che non restituisce un valore di ritorno", "Programmazione", "Medio"),
("26", "0", "E' una funzione che contiene puntatori", "Programmazione", "Medio"),
("26","0", "E' una funzione privata", "Programmazione", "Medio"),
("26", "0", "E' una funzione che restituisce un valore di ritorno", "Programmazione", "Medio"),

("27","1", "E' una libreria", "Programmazione", "Medio"),
("27", "0", "E' un'estensione dell'IDE", "Programmazione", "Medio"),
("27","0", "E' una stringa della Superclasse", "Programmazione", "Medio"),
("27", "0", "E' una stringa di una superclasse", "Programmazione", "Medio"),

("28","0", "Con il comando 'create table(//attributi)'", "Programmazione", "Medio"),
("28", "0", "Con il comando 'create table(//attributi):' ", "Programmazione", "Medio"),
("28","0", "Con il comando 'create Table name(//attributi):'", "Programmazione", "Medio"),
("28", "1", "Con il comando 'create Table name(//attributi)'", "Programmazione", "Medio"),

("29","0", "Permette di selezionare il database'", "Programmazione", "Medio"),
("29", "1", "Permette di fare le interrogazioni al database", "Programmazione", "Medio"),
("29","0", "Permette di selezionare gli attributi", "Programmazione", "Medio"),
("29", "0", "Permette di aggiornare i campi gia scritti di una tabella", "Programmazione", "Medio"),

("30","1", "PHP", "Programmazione", "Medio"),
("30", "0", "CSS", "Programmazione", "Medio"),
("30","0", "HTML", "Programmazione", "Medio"),
("30", "0", "SQL", "Programmazione", "Medio");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("31","0","System.out.println();","Programmazione", "Difficile"),
("31","0","System.out.print();","Programmazione", "Difficile"),
("31","1","System.out.printf;","Programmazione", "Difficile"),
("31","0","System.out.println('Ciao'); ","Programmazione", "Difficile"),

("32","1","<p id='numero' style='color: #ff0000'></p><script type='text/javascript'>document.addEventListener('mouseover', casuale);function casuale() {document.getElementById('numero').innerHTML=Math.round(Math.random()*10+1); } </script>","Programmazione", "Difficile"),
("32","0","document.addEventListener('mousemove', testo);function testo() {  document.getElementById('code').innerHTML='Coding Creativo';} </script>","Programmazione", "Difficile"),
("32","0","document.addEventListener('mouseover', casuale); function casuale() {document.getElementById('numero')","Programmazione", "Difficile"),
("32","0","document.getElementById('tooltip-link1').addEventListener('click', function(){ displayTooltip(2) });","Programmazione", "Difficile"),

("33","0","function somma() {var z = 11 + 5;return z;} var risultato = somma();","Programmazione", "Difficile"),
("33","0","function somma(x, y) {var z = x + y;return z;}","Programmazione", "Difficile"),
("33","0","function somma() {var z = 0;var i;for (i in arguments) {z = z + arguments[i];}return z;}","Programmazione", "Difficile"),
("33","1","function somma() {var z = 13;} var risultato = risultato();","Programmazione", "Difficile"),

("34","0","Assert","Programmazione", "Difficile"),
("34","0","Clear","Programmazione", "Difficile"),
("34","0","Debug","Programmazione", "Difficile"),
("34","1","Doctype.java","Programmazione", "Difficile"),

("35","1","Serve per tutti i numeri interi","Programmazione", "Difficile"),
("35","0","Serve solo per numeri piccoli interi nel quale si conoscono gia' in anticipo","Programmazione", "Difficile"),
("35","0","Serve per copiare una variabile  in due diversi linguaggi di programmazione","Programmazione", "Difficile"),
("35","0","Serve per usufruire delle librerie","Programmazione", "Difficile"),

("36","1","Va' a modificare la posizione naturale di un elemento traslandola","Programmazione", "Difficile"),
("36","0","Modifica la posizione degli elementi","Programmazione", "Difficile"),
("36","0","Modifica i parametri delle tabelle","Programmazione", "Difficile"),
("36","0","Va' a modificare l'indirizzo del documento cha abbiamo salvato","Programmazione", "Difficile"),

("37","1","Serve a scrivere dati direttamente in memoria o ogni volta che vuoi manipolare i dati archiviati nella memoria non gestita","Programmazione", "Difficile"),
("37","0","Non serve","Programmazione", "Difficile"),
("37","0","Serve a scrivere dati direttamente in variabili o ogni volta che vuoi manipolare i dati archiviati nella memoria gestita","Programmazione", "Difficile"),
("37","0","Serve per dichiarare i vettori","Programmazione", "Difficile"),

("38","1","Crea una coppia di file descriptor, utilizzabili per una 'pipe'","Programmazione", "Difficile"),
("38","0","Crea un vettore utilizzabile per una 'pipe'","Programmazione", "Difficile"),
("38","0","Crea un puntatore utilizzabile per una 'pipe'","Programmazione", "Difficile"),
("38","0","E' scritto in modo errato, quindi non funziona","Programmazione", "Difficile"),

("39","0","Sono classi che interagiscono con altre tramite una relazione","Programmazione", "Difficile"),
("39","0","Sono semplici superclassi","Programmazione", "Difficile"),
("39","1","Sono le corrispondenti  di una classe primitiva","Programmazione", "Difficile"),
("39","0","Sono semplici sottoclassi ","Programmazione", "Difficile"),

("40","1","Importa comandi python in macchine che non ne hanno gia' installati","Programmazione", "Difficile"),
("40","0","Importa i file e li apre come file Python","Programmazione", "Difficile"),
("40","0","Serve per mappare il nostro file","Programmazione", "Difficile"),
("40","0","Serve per mappare e modificare file senza autorizzazioni","Programmazione", "Difficile"),

("41","0","Per importare comandi utili al calcolo delle variabili","Programmazione", "Difficile"),
("41","0","Fornisce  moduli utili per i diagrammi","Programmazione", "Difficile"),
("41","1","Fornisce moduli sperimentati e ottimizzati, per realizzare  algoritmi per diversi tipi di compiti percettivi e di comprensione del linguaggio","Programmazione", "Difficile"),
("41","0","Non e' una libreria","Programmazione", "Difficile"),

("42","0","Structure e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi mentre Union e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi","Programmazione", "Difficile"),
("42","1","Union e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi mentre Structure e' un tipo di dati definito dall'utente in linguaggio C che consente di combinare insieme dati di tipi diversi","Programmazione", "Difficile"),
("42","0","Struct viene usato in C mentre Union viene usato in Python","Programmazione", "Difficile"),
("42","0","Union viene usato per la tipologia di attributo mentre Struct per stampare la variabile","Programmazione", "Difficile"),

("43","0","return 0 non restituisce errore percio' non lascia 'freezato' il pc, mentre system() si'","Programmazione", "Difficile"),
("43","0","return 0 restituisce errore percio' non lascia 'freezato' il pc, mentre system() si'","Programmazione", "Difficile"),
("43","0","system() non restituisce errore percio' lascia 'freezato' il pc, mentre return 0 si'","Programmazione", "Difficile"),
("43","1","return 0 fa parte della libreria standard di C, percio' non serve utilizzare una funzione derivata da stdlib.h come system() per freezare la bash di Windows","Programmazione", "Difficile"),

("44","1","HTML","Programmazione", "Difficile"),
("44","0","JavaScript","Programmazione", "Difficile"),
("44","0","Java","Programmazione", "Difficile"),
("44","0","Assembly","Programmazione", "Difficile"),

("45","0","Oracle VirtualBox","Programmazione", "Difficile"),
("45","0","VMWare","Programmazione", "Difficile"),
("45","1","Java Runtime Environment","Programmazione", "Difficile"),
("45","0","Java Virtual Machine","Programmazione", "Difficile");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("46","1","Serve per una navigazione non salvata e i dati locali associati alla sessione vengono cancellati","Sicurezza", "Facile"),
("46","0","A rivelare eventuali malware e virus","Sicurezza", "Facile"),
("46","0","Ad effettuare un aggiornamento","Sicurezza", "Facile"),
("46","0","Ad evitare spam","Sicurezza", "Facile"),

("47","0","E' un apparecchio usato per difendere il pc da altri utenti ","Sicurezza", "Facile"),
("47","1","E' un software che protegge dai codici dannosi e malware ","Sicurezza", "Facile"),
("47","0","E' un apparecchio che protegge dai codici dannosi e malware ","Sicurezza", "Facile"),
("47","0","E' un'applicazione preinstallata nel pc","Sicurezza", "Facile"),

("48","0","Un canale pubblico di comunicazione","Sicurezza", "Facile"),
("48","0","Un canale privato tra più utenti ","Sicurezza", "Facile"),
("48","1","Una rete privata  virtuale ","Sicurezza", "Facile"),
("48","0","Un antivirus","Sicurezza", "Facile"),

("49","0","Un programma volto a proteggere i file dai malware","Sicurezza", "Facile"),
("49","1","Un apparecchio / software utilizzato per filtrare pacchetti indesiderati ","Sicurezza", "Facile"),
("49","0","Un blocco di router collegati tra loro ","Sicurezza", "Facile"),
("49","0","Uno Switch connesso tra due router ","Sicurezza", "Facile"),

("50","0","Un sistema per la riparazione dei pc","Sicurezza", "Facile"),
("50","0","Uno scambio di informazioni tra l’utente e il server","Sicurezza", "Facile"),
("50","1","Una truffa informatica","Sicurezza", "Facile"),
("50","0","Un corso avanzato informatico ","Sicurezza", "Facile"),

("51","0","Inoltrare messaggi ai propri contatti ","Sicurezza", "Facile"),
("51","0","E' un processo informatico ","Sicurezza", "Facile"),
("51","1","E' la ricezione di messaggi pubblicitari non richiesti ","Sicurezza", "Facile"),
("51","0","E' un dispositivo hardware","Sicurezza", "Facile"),

("52","1","Parrot OS","Sicurezza", "Facile"),
("52","0","Xubuntu","Sicurezza", "Facile"),
("52","0","Manjaro","Sicurezza", "Facile"),
("52","0","Endeavour OS","Sicurezza", "Facile"),

("53","1","Processo operativo di analisi o valutazione della sicurezza di un sistema informatico","Sicurezza", "Facile"),
("53","0","E' un processo volto a proteggere l’utente","Sicurezza", "Facile"),
("53","0","E' un processo di riparazione  dell'hardware","Sicurezza", "Facile"),
("53","0","E' un processo di riparazione  del software","Sicurezza", "Facile"),

("54","0","Un creatore di un social network ","Sicurezza", "Facile"),
("54","0","Un ideatore di motori di ricerca ","Sicurezza", "Facile"),
("54","0","Una IA","Sicurezza", "Facile"),
("54","1","Un cracker che introdusse la tecnica di IP Spoofing","Sicurezza", "Facile"),

("55","1","Il computer dell’utente e' il client e quello del fornitore un server","Sicurezza", "Facile"),
("55","0","Il computer dell’utente e' il server  e quello del fornitore un client","Sicurezza", "Facile"),
("55","0","Non ci sono differenze","Sicurezza", "Facile"),
("55","0","Sono usati in ambiti diversi ","Sicurezza", "Facile"),

("56","0","Client/Server","Sicurezza", "Facile"),
("56","0","Broadcast","Sicurezza", "Facile"),
("56","0","Multicast","Sicurezza", "Facile"),
("56","1","Peer to Peer","Sicurezza", "Facile"),

("57","0","Cheer Coaches Association of Michigan","Sicurezza", "Facile"),
("57","1","Client Card Conditional Access Module","Sicurezza", "Facile"),
("57","0","Cher Construction Association of Michigan ","Sicurezza", "Facile"),
("57","0","Cheer Constructure Area of Michigan","Sicurezza", "Facile"),

("58","1","Perche' e' poco sicura ","Sicurezza", "Facile"),
("58","0","Perche' perde di latenza ","Sicurezza", "Facile"),
("58","0","Perche' non ha copertura sicura","Sicurezza", "Facile"),
("58","0","Perche' c’e' il copyright","Sicurezza", "Facile"),

("59","1","Per disturbare i segnali radio ","Sicurezza", "Facile"),
("59","0","Per testare i firewall ","Sicurezza", "Facile"),
("59","0","Per testare gli antivirus","Sicurezza", "Facile"),
("59","0","Per eliminare i file ","Sicurezza", "Facile"),

("60","1","Una tecnica usata per attaccare applicazioni che gestiscono dati attraverso database relazionali sfruttando il linguaggio SQL","Sicurezza", "Facile"),
("60","0","In tecnica di interrogazioni del database","Sicurezza", "Facile"),
("60","0","Una tecnica di eliminazioni del database in SQL","Sicurezza", "Facile"),
("60","0","Una tecnica di duplicazione di un database ","Sicurezza", "Facile");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("61","0","E' l'operazione che permette il trasferimento dei dati  da un computer ad un altro tramite una specifica porta di comunicazione","Sicurezza", "Medio"),
("61","1","E' una tecnica simile al port forwarding, con la differenza che non c'e' necessariamente bisogno di conoscere l'indirizzo IP del destinatario","Sicurezza", "Medio"),
("61","0","E' un protocollo di rete per la creazione di impostazioni Network Address Translation ","Sicurezza", "Medio"),
("61","0","Viene utilizzato per comunicare tra due host","Sicurezza", "Medio"),

("62","1","Avast Free Antivirus","Sicurezza", "Medio"),
("62","0","Ethereal","Sicurezza", "Medio"),
("62","0","nmap","Sicurezza", "Medio"),
("62","0","Aircrack -ng","Sicurezza", "Medio"),

("63","1","Un attacco illegale che sfrutta le vulnerabilità di un applicazione","Sicurezza", "Medio"),
("63","0","Una sorta di firewall","Sicurezza", "Medio"),
("63","0","Un antivirus","Sicurezza", "Medio"),
("63","0","Un collegamento tramite fibra ottica tra router","Sicurezza", "Medio"),

("64","0","Cisco Packet Tracer","Sicurezza", "Medio"),
("64","1","Metasploitable","Sicurezza", "Medio"),
("64","0","Connessione in fibra ottica tramite RJ-45 (Ethernet)","Sicurezza", "Medio"),
("64","0","Cablaggio","Sicurezza", "Medio"),

("65","1","Hack the Box","Sicurezza", "Medio"),
("65","0","Nexths","Sicurezza", "Medio"),
("65","0","Drako","Sicurezza", "Medio"),
("65","0","Dynamic","Sicurezza", "Medio"),

("66","0","E' lo studio di una determinata applicazione tramite il manuale","Sicurezza", "Medio"),
("66","1","E' lo studio del comportamento di una persona al fine di prendere informazioni utili","Sicurezza", "Medio"),
("66","0","E' una guida introduttiva","Sicurezza", "Medio"),
("66","0","E' un  team di progetto","Sicurezza", "Medio"),

("67","0","E' un percorso informatico per arrivare al problema","Sicurezza", "Medio"),
("67","0","Nella sicurezza informatica è un blocco che non permette di fa individuare l’indirizzo ip da chiunque","Sicurezza", "Medio"),
("67","0","Nella sicurezza informatica è un blocco che non permette di fa individuare l’indirizzo ip da fonti di terze parti","Sicurezza", "Medio"),
("67","1","Nella crittografia per indicare un attacco informatico in cui qualcuno segretamente ritrasmette o altera la comunicazione tra due parti che credono di comunicare direttamente tra di loro","Sicurezza", "Medio"),

("68","0","Phishing","Sicurezza", "Medio"),
("68","0","Bruteforce Attack","Sicurezza", "Medio"),
("68","0","Defacing","Sicurezza", "Medio"),
("68","1","Denial of service","Sicurezza", "Medio"),

("69","0","SDP","Sicurezza", "Medio"),
("69","0","SNA","Sicurezza", "Medio"),
("69","0","NBF","Sicurezza", "Medio"),
("69","1","WPA3 / WPA2-PSK","Sicurezza", "Medio"),

("70","1","Chiavetta USB che ruba informazioni","Sicurezza", "Medio"),
("70","0","Malware che ruba informazioni","Sicurezza", "Medio"),
("70","0","Firewall","Sicurezza", "Medio"),
("70","0","Floppy Disk che ruba informazioni","Sicurezza", "Medio"),

("71","0","E' un protocollo di rete","Sicurezza", "Medio"),
("71","0","Una chiave WEP","Sicurezza", "Medio"),
("71","1","E' un adattatore USB Wi-Fi ad alte prestazioni","Sicurezza", "Medio"),
("71","0","Un tipo di server","Sicurezza", "Medio"),

("72","0","Sono tutti protocolli di rete","Sicurezza", "Medio"),
("72","0","Sono sinonimi","Sicurezza", "Medio"),
("72","1","Il Virus e' un software dannoso  che distrugge i dati mentre il Trojan e' un software dannoso che appare come software affidabile per accedere al sistema di destinazione","Sicurezza", "Medio"),
("72","0","Il Trojan e' un software dannoso  che distrugge i dati mentre il Virus e' un software dannoso che appare come software affidabile per accedere al sistema di destinazione","Sicurezza", "Medio"),

("73","0","15","Sicurezza", "Medio"),
("73","0","7","Sicurezza", "Medio"),
("73","0","9","Sicurezza", "Medio"),
("73","1","3","Sicurezza", "Medio"),

("74","0","Una chiavetta con malware al suo interno","Sicurezza", "Medio"),
("74","1","Un dispositivo con le sembianze di una chiavetta USB che manda sovraccarichi di alta tensione","Sicurezza", "Medio"),
("74","0","Una chiavetta danneggiata","Sicurezza", "Medio"),
("74","0","Una chiavetta che elimina tutti i dati dell’utente","Sicurezza", "Medio"),

("75","1","Un malfunzionamento dovuto ad un attacco informatico in cui si fanno esaurire deliberatamente le risorse di un sistema informatico","Sicurezza", "Medio"),
("75","0","Un malfunzionamento  dovuto a uno sbalzo di tensione provocato da una USB killer","Sicurezza", "Medio"),
("75","0","Un software per fare port-mapping","Sicurezza", "Medio"),
("75","0","Un protocollo di sicurezza volto a trovare bug ed eventuali errori","Sicurezza", "Medio");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("76","0","La tecnica di IP-Spoofing","Sicurezza", "Difficile"),
("76","1","E' un attacco che ripiazza il contenuto di un sito in modo indesiderato","Sicurezza", "Difficile"),
("76","0","E' un software audio","Sicurezza", "Difficile"),
("76","0","E' una tecnica di DDoS","Sicurezza", "Difficile"),

("77","1","Lorenzo Faletra (A.K.A. palinuro)","Sicurezza", "Difficile"),
("77","0","Il Cippe","Sicurezza", "Difficile"),
("77","0","Monitor (A.K.A. eschimese)","Sicurezza", "Difficile"),
("77","0","Dario Moccia (A.K.A. l'etrusco)","Sicurezza", "Difficile"),

("78","1","Nei Malware il payload e' il carico trasportato da strumenti di compromissione del sistema","Sicurezza", "Difficile"),
("78","0","Nella rete il payload e' l'handshake tra client e server","Sicurezza", "Difficile"),
("78","0","Nei Malware il payload e' un trojan","Sicurezza", "Difficile"),
("78","0","Nei Malware il payload e' un ransomware","Sicurezza", "Difficile"),

("79","1","Un server SOCKS e' un particolare tipo di proxy che permette di effettuare connessioni TCP dirette tra computer su due reti IP differenti nei casi in cui un instradamento diretto non sia disponibile","Sicurezza", "Difficile"),
("79","0","Il tunneling con SOCKetS e' un particolare modo di sfruttare la connessione per mandare dati integri","Sicurezza", "Difficile"),
("79","0","E' uno sviluppo hardware della NIC (Scheda di rete)","Sicurezza", "Difficile"),
("79","0","E' un attacco di tipo MITM (Man in the Middle)","Sicurezza", "Difficile"),

("80","0","Il tunneling SSH e' la creazione di rete privata","Sicurezza", "Difficile"),
("80","0","Il tunneling SSH e' la modifica di una rete pubblica","Sicurezza", "Difficile"),
("80","0","Il tunneling SSH e' duplicazione della rete pubblica","Sicurezza", "Difficile"),
("80","1","Il tunneling SSH e' un meccanismo che permette di fare il forwarding di porte fra client e server","Sicurezza", "Difficile"),

("81","0","Il watering hole e' una tecnica che va ad infettare gli utenti finali spargendo virus nei PC","Sicurezza", "Difficile"),
("81","0","Il watering hole e' una tecnica che va ad infettare gli utenti finali spargendo virus nell'hardware","Sicurezza", "Difficile"),
("81","1","Il watering hole e' una tecnica che va ad infettare gli utenti finali spargendo virus nei siti web","Sicurezza", "Difficile"),
("81","0","Il watering hole e' una tecnica che va ad infettare gli utenti finali spargendo virus nelle applicazioni","Sicurezza", "Difficile"),

("82","0","Il pharming manipola il traffico di un sito e le informazioni confidenziali vengono rubate","Sicurezza", "Difficile"),
("82","1","Il pharming manipola il traffico di un applicazione e le informazioni confidenziali vengono rubate","Sicurezza", "Difficile"),
("82","0","Il pharming manipola la comunicazione di dati di un componente hardware e le informazioni confidenziali vengono rubate","Sicurezza", "Difficile"),
("82","0","Il pharming e' sinonimo di phishing","Sicurezza", "Difficile"),

("83","1","E' un tipo di attacco dove i malintenzionati iniettano codice javascript dannoso in una pagina web","Sicurezza", "Difficile"),
("83","0","E' un tipo di attacco dove i malintenzionati fanno la sql injection a diversi siti web","Sicurezza", "Difficile"),
("83","0","E' un attacco DDoS","Sicurezza", "Difficile"),
("83","0","E' un tipo di attacco che va a colpire gli utenti finali in modo tale da rubare loro le carte di credito","Sicurezza", "Difficile"),

("84","0","Un attacco di tipo Social Engineering che va a colpire i server","Sicurezza", "Difficile"),
("84","1","Un attacco di tipo Social Engineering che va a colpire gli utenti utilizzando i social media","Sicurezza", "Difficile"),
("84","0","Un attacco di tipo Social Engineering che va a colpire l'hardware","Sicurezza", "Difficile"),
("84","0","Un attacco di tipo Social Engineering che crea un social network fittizio","Sicurezza", "Difficile"),

("85","0","E' un tipo di attacco che serve ad effettuare l'infezione degli usernet, facendoli diventare dei botnet","Sicurezza", "Difficile"),
("85","0","E' un tipo di attacco che serve ad individuare i pacchetti trasmessi in una rete","Sicurezza", "Difficile"),
("85","0","E' un tipo di attacco che serve ad ottenere il controllo delle periferiche in remoto","Sicurezza", "Difficile"),
("85","1","E' un tipo di attacco che serve ad ottenere accesso ad un sistema","Sicurezza", "Difficile"),

("86","1","La CCcam trasmette in diretta senza ritardi perche' si limita a decrittografare i pacchetti , mentre l'IPTV ha un ritardo che va da 5-60 secondi ma trasmette in qualita' massima","Sicurezza", "Difficile"),
("86","0","L'IPTV trasmette in diretta senza ritardi perche' si limita a decrittografare i pacchetti , mentre la CCcam ha un ritardo che va da 5-60 secondi ma trasmette in qualita' massima","Sicurezza", "Difficile"),
("86","0","La CCcam e' piu' costosa dell'IPTV","Sicurezza", "Difficile"),
("86","0","L'IPTV e' piu' veloce della CCcam","Sicurezza", "Difficile"),

("87","0","Su Windows si puo' cambiare andando sulle impostazioni dello store","Sicurezza", "Difficile"),
("87","1","Su Windows si puo' cambiare andando sul pannello di controllo","Sicurezza", "Difficile"),
("87","0","Su Windows non si puo' cambiare","Sicurezza", "Difficile"),
("87","0","Su Windows si puo' cambiare resettare rimuovendo e rimettendo la batteria CMOS","Sicurezza", "Difficile"),

("88","0","Una backdoor serve a permettere l'accesso di un malintenzionato in locale","Sicurezza", "Difficile"),
("88","0","Una backdoor serve a negare l'accesso di un malintenzionato in remoto","Sicurezza", "Difficile"),
("88","1","Una backdoor serve a permettere l'accesso di un malintenzionato in remoto","Sicurezza", "Difficile"),
("88","0","Una backdoor serve a negare l'accesso di un malintenzionato in locale","Sicurezza", "Difficile"),

("89","1","E' uno strumento OSINT (Open Source Intelligence) per enumerare le risorse pubbliche in diversi cloud","Sicurezza", "Difficile"),
("89","0","E' uno strumento OSINT (Open Source Intelligence) per enumerare le risorse private in diversi cloud","Sicurezza", "Difficile"),
("89","0","E' uno strumento OSINT (Open Source Intelligence) per enumerare le risorse pubbliche nelle reti private","Sicurezza", "Difficile"),
("89","0","E' uno strumento OSINT (Open Source Intelligence) per enumerare le risorse pubbliche nelle reti accessibili a tutti","Sicurezza", "Difficile"),

("90","0","MSOLShare","Sicurezza", "Difficile"),
("90","0","MSOLStore","Sicurezza", "Difficile"),
("90","0","MSOLString","Sicurezza", "Difficile"),
("90","1","MSOLSpray","Sicurezza", "Difficile");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("226","1","Read Only Memory","Hardware", "Facile"),
("226","0","Regularly Only Memory","Hardware", "Facile"),
("226","0","Recovery Only Memory","Hardware", "Facile"),
("226","0","Reload Only Memory","Hardware", "Facile"),

("227","0","Funziona con una palla","Hardware", "Facile"),
("227","1","Funziona con un lettore ottico","Hardware", "Facile"),
("227","0","Funziona con un laser","Hardware", "Facile"),
("227","0","Funziona tramite lo sfregamento del tessuto","Hardware", "Facile"),

("228","0","Tastiera","Hardware", "Facile"),
("228","0","Mouse","Hardware", "Facile"),
("228","1","Monitor","Hardware", "Facile"),
("228","0","Videocamera","Hardware", "Facile"),

("229","0","Cassa","Hardware", "Facile"),
("229","0","Monitor","Hardware", "Facile"),
("229","1","Microfono","Hardware", "Facile"),
("229","0","Stampante","Hardware", "Facile"),

("230","0","Una scatola","Hardware", "Facile"),
("230","1","Un contenitore di ferro e/o di vetro contenente i componenti del pc","Hardware", "Facile"),
("230","0","Un contenitore esclusivamente di ferro contenente i componenti del pc","Hardware", "Facile"),
("230","0","Il processore","Hardware", "Facile"),

("231","0","Basta il mouse","Hardware", "Facile"),
("231","0","La webcam","Hardware", "Facile"),
("231","0","Porta USB","Hardware", "Facile"),
("231","1","Il masterizzatore","Hardware", "Facile"),

("232","0","Perche' il microfono delle cuffie e' rotto","Hardware", "Facile"),
("232","0","Perche' le cuffie non sono della stessa marca del pc","Hardware", "Facile"),
("232","0","Perche' la porta AUX ha problemi","Hardware", "Facile"),
("232","1","Perche' le cuffie sono collegate in output e non in input","Hardware", "Facile"),

("233","0","Nessuna differenza","Hardware", "Facile"),
("233","0","Leggera differenza ma solo tattile","Hardware", "Facile"),
("233","1","Discreta differenza tattile e in velocita' di risposta","Hardware", "Facile"),
("233","0","Differenza in tutto","Hardware", "Facile"),

("234","0","Puo' essere di vantaggio a chi scrive, per il rumore dei suoi tasti","Hardware", "Facile"),
("234","1","Puo' essere di vantaggio in campo gaming per la sua velocita' di risposta","Hardware", "Facile"),
("234","0","Costa di meno","Hardware", "Facile"),
("234","0","Sono le piu' rare e quindi hanno un costo maggiore","Hardware", "Facile"),

("235","1","Puo' essere di vantaggio a chi scrive, per la sua leggerezza dei tasti","Hardware", "Facile"),
("235","0","Puo' avere vantaggi in campo gaming per la sua velocita' di pressione","Hardware", "Facile"),
("235","0","Costa di piu'","Hardware", "Facile"),
("235","0","Sono le piu' comuni quindi e' possibile trovarle piu' facilmente","Hardware", "Facile"),

("236","0","Puntini","Hardware", "Facile"),
("236","0","Points","Hardware", "Facile"),
("236","1","PIN","Hardware", "Facile"),
("236","0","PIP","Hardware", "Facile"),

("237","1","Fibra di vetro e resina artificiale collante","Hardware", "Facile"),
("237","0","Solo rame","Hardware", "Facile"),
("237","0","Rame e silicio","Hardware", "Facile"),
("237","0","Silicio, oro, zinco, rame e vetro","Hardware", "Facile"),

("238","0","Rame","Hardware", "Facile"),
("238","1","Sicilio","Hardware", "Facile"),
("238","0","Oro","Hardware", "Facile"),
("238","0","Argento","Hardware", "Facile"),

("239","0","La densita' della grandezza di un mouse misurata in pollici","Hardware", "Facile"),
("239","0","La densita' del suo cursore","Hardware", "Facile"),
("239","0","La grandezza del mouse comparabile alla mano umana","Hardware", "Facile"),
("239","1","La velocita' del cursore","Hardware", "Facile"),

("240","0","A raffreddare il processore","Hardware", "Facile"),
("240","1","Ad avere un buon airflow cosi' da non surriscaldare i componenti","Hardware", "Facile"),
("240","0","A mantenere sempre la temperatura costante","Hardware", "Facile"),
("240","0","A decorare il PC","Hardware", "Facile");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("241","0","PSU","Hardware", "Medio"),
("241","0","RAM","Hardware", "Medio"),
("241","0","SSD","Hardware", "Medio"),
("241","1","GPU","Hardware", "Medio"),

("242","1","E' una tecnologia usata dalle schede madri per aumentare la frequenza delle ram","Hardware", "Medio"),
("242","0","E' un profilo che si fanno i professionisti quando resettano il BIOS","Hardware", "Medio"),
("242","0","E' un profilo integrato del pc che si può accedere solo dall’esterno","Hardware", "Medio"),
("242","0","E' una tecnologia usata per aggiornare il BIOS ","Hardware", "Medio"),

("243","0","5","Hardware", "Medio"),
("243","1","20","Hardware", "Medio"),
("243","0","50","Hardware", "Medio"),
("243","0","100","Hardware", "Medio"),

("244","0","i3 9100F","Hardware", "Medio"),
("244","1","Ryzen 7 3800X","Hardware", "Medio"),
("244","0","i7 3770F","Hardware", "Medio"),
("244","0","Ryzen 5 5600G","Hardware", "Medio"),

("245","0","GTX 1030","Hardware", "Medio"),
("245","0","RTX 2060","Hardware", "Medio"),
("245","0","RX 5500XT","Hardware", "Medio"),
("245","1","GTX 1080TI","Hardware", "Medio"),

("246","1","Sono due aziende differenti, una sviluppa solo GPU, l’altro anche CPU","Hardware", "Medio"),
("246","0","Sono due componenti diversi","Hardware", "Medio"),
("246","0","Sono due aziende di componenti, una sempre inferiore all’altra","Hardware", "Medio"),
("246","0","Sono due aziende completamente uguali, annettendosi","Hardware", "Medio"),

("247","1","Sono i colori dei led: rosso - verde - blu","Hardware", "Medio"),
("247","0","E' un componente del pc","Hardware", "Medio"),
("247","0","E' una parte essenziale del processore","Hardware", "Medio"),
("247","0","Non vuol dire nulla","Hardware", "Medio"),

("248","1","La differenza è che il processo è svolto da un solo core e non da tanti ","Hardware", "Medio"),
("248","0","La differenza sta nel tipo di processore","Hardware", "Medio"),
("248","0","La differenza sta nel tipo di applicazione","Hardware", "Medio"),
("248","0","La differenza sta nella scelta della scheda madre, a seconda di essa, i processi si muovono","Hardware", "Medio"),

("249","0","i3 9100F","Hardware", "Medio"),
("249","0","Ryzen 5 5600G","Hardware", "Medio"),
("249","0","i7 3770F","Hardware", "Medio"),
("249","1","Ryzen 7 3800X","Hardware", "Medio"),

("250","0","Serve per le schede madri","Hardware", "Medio"),
("250","1","Serve per i processori","Hardware", "Medio"),
("250","0","Serve per le RAM","Hardware", "Medio"),
("250","0","Serve per gli SSD","Hardware", "Medio"),

("251","0","Alaska","Hardware", "Medio"),
("251","0","Polo nord","Hardware", "Medio"),
("251","1","Africa","Hardware", "Medio"),
("251","0","Russia","Hardware", "Medio"),

("252","1","Le gpu sono costose perche' sono il componente piu' ricercato e quindi viene richiesta piu' potenza in essa","Hardware", "Medio"),
("252","0","Le gpu sono costose perche' sono essenziali per far funzionare il PC","Hardware", "Medio"),
("252","0","Le gpu sono costose perche' hanno componenti costosi","Hardware", "Medio"),
("252","0","Le gpu sono costose perche' vengono utilizzate dai miner","Hardware", "Medio"),

("253","0","Perche' per la pandemia i chip erano esplosivi","Hardware", "Medio"),
("253","1","Perche' per la pandemia le grandi aziende erano a corto di materie prime","Hardware", "Medio"),
("253","0","Perche' per la pandemia le grandi aziende stavano fallendo e non potevano pagare i lavoratori","Hardware", "Medio"),
("253","0","Perche' per la pandemia ci sono state delle interruzioni del lavoro","Hardware", "Medio"),

("254","0","Perche' altrimenti il computer potrebbe fondersi","Hardware", "Medio"),
("254","0","Perche' altrimenti i componenti potrebbero bruciarsi","Hardware", "Medio"),
("254","1","Perche' c'e' il rischio di continui crash del PC","Hardware", "Medio"),
("254","0","Perche' il PC potrebbe risentirne con il tempo","Hardware", "Medio"),

("255","0","La differenza sta nella potenza, quelli AIO sono meno potenti","Hardware", "Medio"),
("255","0","La differenza sta nella durata","Hardware", "Medio"),
("255","0","La differenza sta nel costo","Hardware", "Medio"),
("255","1","La differenza sta nel rumore e nella potenza, a vantaggio di quelli AIO","Hardware", "Medio");

INSERT INTO risposte (num_domanda, corretta, testo, fk_corso, difficoltaDomanda) VALUES
("256","1","i7-7740X","Hardware", "Difficile"),
("256","0","i7-3770F","Hardware", "Difficile"),
("256","0","Ryzen 9 5950","Hardware", "Difficile"),
("256","0","Ryzen 5 5600","Hardware", "Difficile"),

("257","0","Ryzen 5 3600","Hardware", "Difficile"),
("257","1","i7-12700","Hardware", "Difficile"),
("257","0","Ryzen 5 5600","Hardware", "Difficile"),
("257","0","Ryzen 3 3300","Hardware", "Difficile"),

("258","0","i9-12900KS","Hardware", "Difficile"),
("258","0","i7-3770F","Hardware", "Difficile"),
("258","0","Ryzen 5 5600","Hardware", "Difficile"),
("258","1","Ryzen 3 3300","Hardware", "Difficile"),

("259","0","La differenza sta nell’elettricita' data ai componenti, il modulare da meno potenza","Hardware", "Difficile"),
("259","1","Il non modulare ha attacchi statici e quindi non rimovibili, dunque e' piu' ingombrante","Hardware", "Difficile"),
("259","0","La differenza sta nell’elettricita' data ai componenti, il modulare da' piu' potenza","Hardware", "Difficile"),
("259","0","La differenza sta all’esterno, il modulare non conduce","Hardware", "Difficile"),

("260","0","ASROCK H310CM-DVS","Hardware", "Difficile"),
("260","0","GIGABYTE GA-H310M-H","Hardware", "Difficile"),
("260","0","BIOSTAR TB360-BTC","Hardware", "Difficile"),
("260","1","MSI B450","Hardware", "Difficile"),

("261","0","4GB","Hardware", "Difficile"),
("261","1","8GB","Hardware", "Difficile"),
("261","0","16GB","Hardware", "Difficile"),
("261","0","32GB","Hardware", "Difficile"),

("262","1","Una e' non volatile, l’altra e' volatile","Hardware", "Difficile"),
("262","0","VRAM e' meno potente della NVRAM","Hardware", "Difficile"),
("262","0","Non ci sono differenze","Hardware", "Difficile"),
("262","0","Esistono entrambe e sono dentro alla ram del pc, la differenza e' vram non e' utilizzata","Hardware", "Difficile"),

("263","0","500W","Hardware", "Difficile"),
("263","0","600W","Hardware", "Difficile"),
("263","0","700W","Hardware", "Difficile"),
("263","1","800W","Hardware", "Difficile"),

("264","0","La differenza e' il tipo di 'scheletro'","Hardware", "Difficile"),
("264","1","La differenza e' la qualita' della PSU","Hardware", "Difficile"),
("264","0","La differenza e' il tipo di potenza","Hardware", "Difficile"),
("264","0","La differenza e' la marca","Hardware", "Difficile"),

("265","1","Sono molto piu' veloci, ma costano molto di piu' e non sono ancora in commercio","Hardware", "Difficile"),
("265","0","Sono molto piu' veloci e sono piu' economiche","Hardware", "Difficile"),
("265","0","Sono piu' lente, pero' sono piu' economiche e sono piu' reperibili","Hardware", "Difficile"),
("265","0","Sono piu' resistenti e sono anche impermeabili","Hardware", "Difficile"),

("266","0","Aiuta la visualizzazione dello schermo mettendo in risalto le parti meno luminose","Hardware", "Difficile"),
("266","0","Aiuta la sincronizzazione tra le parti mancanti di un gioco e la RAM","Hardware", "Difficile"),
("266","0","Sincronizza lo schermo con la GPU per non far sfarfallare le immagini","Hardware", "Difficile"),
("266","1","Aiuta a sincronizzare il secondo schermo con il primo","Hardware", "Difficile"),

("267","0","La differenza e' il tipo di sincronizzazione","Hardware", "Difficile"),
("267","1","La differenza e' che una e' di NVIDIA, l’altra e' di AMD","Hardware", "Difficile"),
("267","0","La differenza e' che una e' libera, l’altra e' incatenata","Hardware", "Difficile"),
("267","0","Non ci sono differenze, sono utilizzabili entrambe allo stesso tempo","Hardware", "Difficile"),

("268","0","Verdi","Hardware", "Difficile"),
("268","0","Blu","Hardware", "Difficile"),
("268","1","Rossi","Hardware", "Difficile"),
("268","0","Marroni","Hardware", "Difficile"),

("269","0","La differenza e' il costo, non cambia molto se non la marca del monitor","Hardware", "Difficile"),
("269","0","La differenza e' la luminosita', Amoled e' piu' luminoso","Hardware", "Difficile"),
("269","0","La differenza e' il consumo di corrente, Amoled consuma di piu'","Hardware", "Difficile"),
("269","1","La differenza sta nel tipo di pannello, gli LCD sono retroilluminati invece negli amoled i pixel si illuminano da soli","Hardware", "Difficile"),

("270","1","La funzione dei MINI-LED e' aumentare il numero di pixel effettivi del monitor","Hardware", "Difficile"),
("270","0","La funzione dei MINI-LED e' diminuire la potenza richiesta del monitor","Hardware", "Difficile"),
("270","0","La funzione dei MINI-LED e' aumentare la precisione del monitor","Hardware", "Difficile"),
("270","0","La funzione dei MINI-LED e' diminuire la risoluzione del monitor","Hardware", "Difficile");