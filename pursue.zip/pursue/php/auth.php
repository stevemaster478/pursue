<?php
    if(!isset($_SESSION["name"])) {
        header("Location: webpages/login.html");
        exit();
    }
