<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../phpLogin/index.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benvenuto</title>
</head>

<body>
    <?php echo "<h1>Benvenuto " . $_SESSION['username'] . "</h1>"; ?>
    <?php echo "<h2> Procedi </h2>"; ?>
    <a href="../courses.html"> Continua</a>
    <a href="logout.php">      Logout</a>
</body>



</html>