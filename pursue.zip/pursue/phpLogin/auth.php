<?php
    if(!isset($_SESSION["name"])) {
        header("Location: ../phpLogin/index.php");
        exit();
    }
