<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Quiz - pursu(e)</title>
    <link rel="stylesheet" href="app.css" />
</head>

<body>
    <div class="container">
        <div id="home" class="flex-center flex-column">
            <h1>Quiz - pursu(e)</h1>
            <a class="btn" href="question.php?n=1">Gioca</a>
            <a class="btn" href="final.php">Record</a>
        </div>
    </div>
</body>

</html>