<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Congratulazioni!</title>
    <link rel="stylesheet" href="app.css" />
</head>

<body>
    <div class="immagine">
        <img src="../assets/images/logo_white-theme.png" style="left: 654px;margin-left: 41.1%;margin-bottom: -10%;">
    </div>
    <div class="container">
        <div id="end" class="flex-center flex-column">
            <h1 id="finalScore"></h1>
            <a class="btn" href="game.html">Gioca di nuovo</a>
            <a class="btn" href="../courses.html">Torna indietro</a>
        </div>
    </div>
    <script src="end.js"></script>
</body>

</html>