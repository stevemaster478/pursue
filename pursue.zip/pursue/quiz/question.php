<!--
<?php include '../phpLogin/config.php'; ?>
<?php
/*
    //Imposta numero domanda
    $num = (int)  $_GET('n');

    //Domanda
    $query = "SELECT * FROM domanda WHERE id_domanda = $num";

    //Risultato
    $res = $mysqli->query($query) or die($mysqli->error.__LINE__);

    $domanda = $res->fetch_assoc();
    
    //Domanda
    $query = "SELECT * FROM domanda WHERE id_domanda = $num";

    //Risultato
    $res = $mysqli->query($query) or die($mysqli->error . __LINE__);

    $domanda = $res->fetch_assoc();
    */
?>

-->
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Quiz - pursu(e)</title>
    <link rel="stylesheet" href="app.css" />
    <link rel="stylesheet" href="game.css" />
</head>

<body>
    <div class="container">
        <div class = "current"> Domanda 1 su 15 </div>
    </div>
</body>
</html>