<?php
$host = "localhost";
$userName = "root";
$password = "";
$dbName = "quiz";

// Create database connection
$conn = new mysqli($host, $userName, $password, $dbName);

// Error Handler
if ($conn->connect_error) {
    printf("Connessione fallita: %s\n", $conn->connect_error);
    exit();
}
