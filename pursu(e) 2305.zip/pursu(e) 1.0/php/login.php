<?php

require_once('config.php');

$email = $connessione->real_escape_string($_POST['email']);
$user = $connessione->real_escape_string($_POST['user']);
$password = $connessione->real_escape_string($_POST['password']);

$sql = "INSERT INTO utente (email, user, password) VALUES ('$email', '$user', '$password')";
if (!$connessione -> query($sql)) {
    echo "registrazione effettuata con successo";
}else{
    echo "errore durante la tua registrazione $sql. " . $connessione->error;
}
$connessione -> close();
?>