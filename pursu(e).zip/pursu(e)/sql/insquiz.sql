USE pursue;

INSERT INTO utente(nomeUtente, pass)
VALUE


INSERT INTO tipologia(tipo, sottotipo)
VALUE

INSERT INTO quiz(id, tipo)
VALUE


INSERT INTO svolge(nomeUtente,id)
VALUE
