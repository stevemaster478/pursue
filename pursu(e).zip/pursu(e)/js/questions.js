// Creare un array e passando il numero, le domande, le opzioni e le risposte
let questions = [
    {
    numb: 1,
    question: "Cosa significa HTML?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
    {
    numb: 2,
    question: "Cosa significa CSS?",
    answer: "Cascading Style Sheet",
    options: [
      "Common Style Sheet",
      "Colorful Style Sheet",
      "Computer Style Sheet",
      "Cascading Style Sheet"
    ]
  },
    {
    numb: 3,
    question: "Cosa significa PHP?",
    answer: "Hypertext Preprocessor",
    options: [
      "Hypertext Preprocessor",
      "Hypertext Programming",
      "Hypertext Preprogramming",
      "Hometext Preprocessor"
    ]
  },
    {
    numb: 4,
    question: "Cosa significa SQL?",
    answer: "Structured Query Language",
    options: [
      "Stylish Question Language",
      "Stylesheet Query Language",
      "Statement Question Language",
      "Structured Query Language"
    ]
  },
    {
    numb: 5,
    question: "Cosa significa XML?",
    answer: "eXtensible Markup Language",
    options: [
      "eXtensible Markup Language",
      "eXecutable Multiple Language",
      "eXTra Multi-Program Language",
      "eXamine Multiple Language"
    ]
  },
  {
    numb: 6,
    question: "Cosa significa HTML?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
  {
    numb: 7,
    question: "What does HTML stand for?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
  {
    numb: 8,
    question: "What does HTML stand for?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
  {
    numb: 9,
    question: "What does HTML stand for?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
  {
    numb: 10,
    question: "What does HTML stand for?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  }
];

let questions = [
  {
  numb: 1,
  question: "Come si usa la funzione “copia” da tastiera? ?",
  answer: "ctrl + c",
  options: [
    "ctrl + t",
    "ctrl + x",
    "ctrl + v",
    "ctrl + c"
  ]
},
  {
  numb: 2,
  question: "Come si usa la funzione “incolla” da tastiera??",
  answer: "ctrl + v",
  options: [
    "ctrl + t",
    "ctrl + x",
    "ctrl + v",
    "ctrl + c"
  ]
},
  {
  numb: 3,
  question: "Che cos’è un’icona??",
  answer: "un'immagine ipertestuale di piccole dimensioni",
  options: [
    "un'immagine ipertestuale di grandi dimensioni",
    "un'immagine di tipo png",
    "un foglio",
    "un'immagine ipertestuale di piccole dimensioni"
  ]
},
{
numb: 4,
question: "Che cos’è più grande??",
answer: "Petabyte",
options: [
  "Gigabyte",
  "Terabyte",
  "Megabyte",
  "Petabyte"
]
},
{
numb: 5,
question: "Come si possono trasferire immagini da telefono a pc? ?",
answer: "tramite cavo usb",
options: [
  "tramite cavo usb",
  "tramite lo sfregamento su schermo",
  "bypassando i dati del telefono",
  "chiedendoli per favore"
]
},
{
numb: 6,
question: "A cosa serve il tasto Windows?",
answer: "ad aprire la finestra di windows in basso",
options: [
  "ad aprire la porta di casa",
  "a chiedere a cortana di accendere windows",
  "ad accendere il pc da spento",
  "ad aprire la finestra di windows in basso"
]
},
{
numb: 7,
question: "Come si scrive il carattere 'È'?",
answer: "alt + 0201",
options: [
  "alt + 4565",
  "alt + 9695",
  "alt + 0201",
  "alt + 0206"
]
},
{
numb: 8,
question: "Come si stampa un file?",
answer: "premendo il tasto destro e andando su 'stampa'",
options: [
  "con il tasto windows",
  "premendo il tasto destro e andando su 'stampa'",
  "con il tasto stamp da tastiera",
  "con il blocco numerico"
]
},
{
numb: 9,
question: "Che cos’è una “scorciatoia da tastiera",
answer: "una combinazione di tasti che svolgono una funzione",
options: [
  "una strada da percorrere più breve",
  "un'algoritmo crittografato che solo Naufull sa decodificare",
  "una combinazione di tasti che svolgono una funzione",
  "lo acer che bontà"
]
},
{
numb: 10,
question: "Cosa succede se metti un programma nel Cestino?",
answer: "si elimina il collegamento ma restano i file nel computer finchè non svuoti il cestino",
options: [
  "ti si apre una pagina google con tutte le tue password visibili",
  "lo disistalla",
  "niente",
  "si elimina il collegamento ma restano i file nel computer finchè non svuoti il cestino"
]
},
{numb: 11,
  question: "Che cos'è ha il formato PDF?",
  answer: "è un documento stampato",
  options: [
    "è una semplice foto",
    "è una foto stampata",
    "è un documento stampato",
    "è un Chiappino stampato"
  ]
  },
  {
  numb: 12,
  question: "Che significa il formato txt?",
  answer: "è un file di testo",
  options: [
    "è un file word",
    "è un file di testo",
    "è un file power point",
    "è un Cavalieri stampato"
  ]
  },
  {
  numb: 13,
  question: "Che significa il formato ppt?",
  answer: "è un file power point",
  options: [
    "è un file word",
    "un plugin di Office 365",
    "è un file power point",
    "è un Uaglione stampato"
  ]
  },
  {
  numb: 14,
  question: "Quale tra i seguenti dispositivi di memoria ha la capacità più alta?",
  answer: "SSD",
  options: [
    "Ram",
    "Floppy-Disk",
    "CD-ROM",
    "SSD"
  ]
  },
  {
    numb: 15,
    question: "Come si fa ad installare Windows su una macchina appena montata?",
    answer: "installando una chiavetta usb con windows preinstallato dentro",
    options: [
      "installandolo dal browser appena il PC si accende",
      "installandolo tramite telefono",
      "riavviando il modem di casa",
      "installando una chiavetta usb con windows preinstallato dentro"
  ]
  }
];


let questions = [
  {
  numb: 1,
  question: "Che cos’è una macchina virtuale?",
  answer: "Software che simula una macchina fisica (pc, client o server)",
  options: [
    "un'computer online accessibile via rete",
    "una macchina volante virtualmente accessibile",
    "un computer dentro un computer",
    "Software che simula una macchina fisica (pc, client o server)"
  ]
},
  {
  numb: 2,
  question: "Che differenza c'è tra HTTP e HTTPS?",
  answer: "fanno due cose uguali ma uno è più sicuro",
  options: [
    "la s",
    "fanno due cose uguali ma uno è più sicuro",
    "fanno due cose diverse ed uno è più sicuro",
    "https non esiste"
  ]
},
  {
  numb: 3,
  question: "Dove si usa il protocollo HTTP?",
  answer: "",
  options: [
    "nelle pagine web",
    "su javascript",
    "solo su google",
    "quando si clicca in un collegamento ipertestuale"
  ]
},
{
numb: 4,
question: "Che cos’è un collegamento ipertestuale?",
answer: "un rinvio da un'unità informativa su supporto digitale ad un'altra",
options: [
  "un collegamento ta due applicazioni",
  "un collegamento tra due siti internet",
  "un rinvio da un'unità informativa su supporto digitale ad un'altra",
  "un collegamento tra bottino e sassuttat"

]
},
{
numb: 5,
question: "Quanto è grande uno Yottabyte (in byte)?",
answer: "1e+24",
options: [
  "1e+32",
  "1e+20",
  "1e+24",
  "1e+26"
]
},
{
numb: 6,
question: "Che cosa fa il kernel?",
answer: "costituisce il nucleo o core di un sistema operativo",
options: [
  "costituisce il nucleo o core di un sistema operativo",
  "assembla parti virtuali del pc in funzionamento",
  "costituisce l'hardwware e ne controlla il flusso di dati",
  "difende il computer da malware e virus"
]


},
{
numb: 7,
question: "Cos’è un hypervisor?",
answer: "è il componente fondamentale per il funzionamento di una macchina virtuale",
options: [
  "è un visore utilizzabile nelle macchine virtuali",
  "è un software per l 'installazione di macchine virtuali",
  "è il componente fondamentale per il funzionamento di una macchina virtuale",
  "è un collegamento ipertestuale ultra caricato"
]
},
{
numb: 8,
question: "Cosa serve la “struttura ad albero” in ambito di salvataggio dati?",
answer: "",
options: [
  "serve per visualizzare i dati gerarchicamente",
  "serve per visualizzare i dati su un albero",
  "serve per aumentare la statura dei dati visualizzati",
  "serve per visualizzare i dati di gerarchie diverse"
]
},
{
numb: 9,
question: "",
answer: "",
options: [
  "",
  "",
  "",
  ""
]
},
{
numb: 10,
question: "",
answer: "",
options: [
  "",
  "",
  "",
  ""
]
},
{numb: 11,
  question: "",
  answer: "",
  options: [
    "",
    "",
    "",
    ""
  ]
  },
  {
  numb: 12,
  question: "",
  answer: "",
  options: [
    "",
    "",
    "",
    ""
  ]
  },
  {
  numb: 13,
  question: "",
  answer: "",
  options: [
    "",
    "",
    "",
    ""
  ]
  },
  {
  numb: 14,
  question: "",
  answer: "",
  options: [
    "",
    "",
    "",
    ""
  ]
  },
  {
    numb: 15,
    question: "",
    answer: "",
    options: [
      "",
      "",
      "",
      ""
  ]
  }
];