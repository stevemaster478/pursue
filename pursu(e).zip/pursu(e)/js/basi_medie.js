let questions = [
    {
    numb: 1,
    question: "Che cos’è una macchina virtuale?",
    answer: "Software che simula una macchina fisica (pc, client o server)",
    options: [
      "un'computer online accessibile via rete",
      "una macchina volante virtualmente accessibile",
      "un computer dentro un computer",
      "Software che simula una macchina fisica (pc, client o server)"
    ]
  },
    {
    numb: 2,
    question: "Che differenza c'è tra HTTP e HTTPS?",
    answer: "fanno due cose uguali ma uno è più sicuro",
    options: [
      "la s",
      "fanno due cose uguali ma uno è più sicuro",
      "fanno due cose diverse ed uno è più sicuro",
      "https non esiste"
    ]
  },
    {
    numb: 3,
    question: "Dove si usa il protocollo HTTP?",
    answer: "",
    options: [
      "nelle pagine web",
      "su javascript",
      "solo su google",
      "quando si clicca in un collegamento ipertestuale"
    ]
  },
  {
  numb: 4,
  question: "Che cos’è un collegamento ipertestuale?",
  answer: "un rinvio da un'unità informativa su supporto digitale ad un'altra",
  options: [
    "un collegamento ta due applicazioni",
    "un collegamento tra due siti internet",
    "un rinvio da un'unità informativa su supporto digitale ad un'altra",
    "un collegamento tra bottino e sassuttat"
  
  ]
  },
  {
  numb: 5,
  question: "Quanto è grande uno Yottabyte (in byte)?",
  answer: "1e+24",
  options: [
    "1e+32",
    "1e+20",
    "1e+24",
    "1e+26"
  ]
  },
  {
  numb: 6,
  question: "Che cosa fa il kernel?",
  answer: "costituisce il nucleo o core di un sistema operativo",
  options: [
    "costituisce il nucleo o core di un sistema operativo",
    "assembla parti virtuali del pc in funzionamento",
    "costituisce l'hardwware e ne controlla il flusso di dati",
    "difende il computer da malware e virus"
  ]
  
  
  },
  {
  numb: 7,
  question: "Cos’è un hypervisor?",
  answer: "è il componente fondamentale per il funzionamento di una macchina virtuale",
  options: [
    "è un visore utilizzabile nelle macchine virtuali",
    "è un software per l 'installazione di macchine virtuali",
    "è il componente fondamentale per il funzionamento di una macchina virtuale",
    "è un collegamento ipertestuale ultra caricato"
  ]
  },
  {
  numb: 8,
  question: "Cosa serve la “struttura ad albero” in ambito di salvataggio dati?",
  answer: "",
  options: [
    "serve per visualizzare i dati gerarchicamente",
    "serve per visualizzare i dati su un albero",
    "serve per aumentare la statura dei dati visualizzati",
    "serve per visualizzare i dati di gerarchie diverse"
  ]
  },
  {
  numb: 9,
  question: "Quanti caratteri diversi possono essere rappresentati con il codice standard ASCII?",
  answer: "128",
  options: [
    "64",
    "128",
    "256",
    "512"
  ]
  },
  {
  numb: 10,
  question: "Dove sono contenuti i dati che vanno persi quando si spegne il pc?",
  answer: "nella RAM",
  options: [
    "nella ROM",
    "nel CD-ROM perchè smette di girare",
    "nella RAM",
    "nell'uscita USB"
  ]
  },
  {numb: 11,
    question: "Che funzione svolge la ALU?",
    answer: "recupera i dati dai registri del processore, processa i dati nell'accumulatore e provvede a salvare il risultato nel registro di uscita.",
    options: [
      "recupera i dati dai registri di sistema, processa i dati dalla scheda video e provvede a mandarli in output.",
      "nessuna di quelle citate",
      "processa i dati di input e quelli di output",
      "recupera i dati dai registri del processore, processa i dati nell'accumulatore e provvede a salvare il risultato nel registro di uscita."
    ]
    },
    {
    numb: 12,
    question: "Che cosa si intende per “linguaggio ad alto livello”?",
    answer: "un linguaggio facilmente comprensibile dai programmatori ma non dalle macchine",
    options: [
      "un linguaggio molto formale",
      "un linguaggio che comprende più linguaggi",
      "un linguaggio di programmazione molto complesso",
      "un linguaggio facilmente comprensibile dai programmatori ma non dalle macchine"
    ]
    },
    {
    numb: 13,
    question: "Cosa sono i registri di sistema?",
    answer: "sono delle opzioni e impostazioni che servono al funzionamento del sistema operativo",
    options: [
      "sono dei video registrati che la polizia può visualizzare in caso di atti illegali",
      "sono dei codici nascosti che servono al funzionamento del sistema operativo",
      "sono delle opzioni e impostazioni che servono al funzionamento del sistema operativo",
      "tutte le risposte sono corrette"
    ]
    },
    {
    numb: 14,
    question: "Qual’è la caratteristica principale di un programma open source?",
    answer: "che non implica limiti sull'utilizzo del software",
    options: [
      "che è aperto a tutti",
      "che è stato creato per tutti i tipi di utenti",
      "che è facilmente ricercabile via web",
      "che non implica limiti sull'utilizzo del software"
    ]
    },
    {
      numb: 15,
      question: "Cosa sono i Java Applets?",
      answer: "",
      options: [
        "sono dei programmi Java eseguibili dal browser",
        "sono delle applicazioni Apple implementati con Java",
        "sono degli apparati Java possibilmente utili nella programmazione",
        "sono degli apparati Java essenziali nella programmazione"
    ]
    }
  ];