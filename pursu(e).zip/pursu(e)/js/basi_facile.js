let questions = [
    {
    numb: 1,
    question: "Come si usa la funzione “copia” da tastiera? ?",
    answer: "ctrl + c",
    options: [
      "ctrl + t",
      "ctrl + x",
      "ctrl + v",
      "ctrl + c"
    ]
  },
    {
    numb: 2,
    question: "Come si usa la funzione “incolla” da tastiera??",
    answer: "ctrl + v",
    options: [
      "ctrl + t",
      "ctrl + x",
      "ctrl + v",
      "ctrl + c"
    ]
  },
    {
    numb: 3,
    question: "Che cos’è un’icona??",
    answer: "un'immagine ipertestuale di piccole dimensioni",
    options: [
      "un'immagine ipertestuale di grandi dimensioni",
      "un'immagine di tipo png",
      "un foglio",
      "un'immagine ipertestuale di piccole dimensioni"
    ]
  },
  {
  numb: 4,
  question: "Che cos’è più grande??",
  answer: "Petabyte",
  options: [
    "Gigabyte",
    "Terabyte",
    "Megabyte",
    "Petabyte"
  ]
  },
  {
  numb: 5,
  question: "Come si possono trasferire immagini da telefono a pc? ?",
  answer: "tramite cavo usb",
  options: [
    "tramite cavo usb",
    "tramite lo sfregamento su schermo",
    "bypassando i dati del telefono",
    "chiedendoli per favore"
  ]
  },
  {
  numb: 6,
  question: "A cosa serve il tasto Windows?",
  answer: "ad aprire la finestra di windows in basso",
  options: [
    "ad aprire la porta di casa",
    "a chiedere a cortana di accendere windows",
    "ad accendere il pc da spento",
    "ad aprire la finestra di windows in basso"
  ]
  },
  {
  numb: 7,
  question: "Come si scrive il carattere 'È'?",
  answer: "alt + 0201",
  options: [
    "alt + 4565",
    "alt + 9695",
    "alt + 0201",
    "alt + 0206"
  ]
  },
  {
  numb: 8,
  question: "Come si stampa un file?",
  answer: "premendo il tasto destro e andando su 'stampa'",
  options: [
    "con il tasto windows",
    "premendo il tasto destro e andando su 'stampa'",
    "con il tasto stamp da tastiera",
    "con il blocco numerico"
  ]
  },
  {
  numb: 9,
  question: "Che cos’è una “scorciatoia da tastiera",
  answer: "una combinazione di tasti che svolgono una funzione",
  options: [
    "una strada da percorrere più breve",
    "un'algoritmo crittografato che solo Naufull sa decodificare",
    "una combinazione di tasti che svolgono una funzione",
    "lo acer che bontà"
  ]
  },
  {
  numb: 10,
  question: "Cosa succede se metti un programma nel Cestino?",
  answer: "si elimina il collegamento ma restano i file nel computer finchè non svuoti il cestino",
  options: [
    "ti si apre una pagina google con tutte le tue password visibili",
    "lo disistalla",
    "niente",
    "si elimina il collegamento ma restano i file nel computer finchè non svuoti il cestino"
  ]
  },
  {numb: 11,
    question: "Che cos'è ha il formato PDF?",
    answer: "è un documento stampato",
    options: [
      "è una semplice foto",
      "è una foto stampata",
      "è un documento stampato",
      "è un Chiappino stampato"
    ]
    },
    {
    numb: 12,
    question: "Che significa il formato txt?",
    answer: "è un file di testo",
    options: [
      "è un file word",
      "è un file di testo",
      "è un file power point",
      "è un Cavalieri stampato"
    ]
    },
    {
    numb: 13,
    question: "Che significa il formato ppt?",
    answer: "è un file power point",
    options: [
      "è un file word",
      "un plugin di Office 365",
      "è un file power point",
      "è un Uaglione stampato"
    ]
    },
    {
    numb: 14,
    question: "Quale tra i seguenti dispositivi di memoria ha la capacità più alta?",
    answer: "SSD",
    options: [
      "Ram",
      "Floppy-Disk",
      "CD-ROM",
      "SSD"
    ]
    },
    {
      numb: 15,
      question: "Come si fa ad installare Windows su una macchina appena montata?",
      answer: "installando una chiavetta usb con windows preinstallato dentro",
      options: [
        "installandolo dal browser appena il PC si accende",
        "installandolo tramite telefono",
        "riavviando il modem di casa",
        "installando una chiavetta usb con windows preinstallato dentro"
    ]
    }
  ];
  