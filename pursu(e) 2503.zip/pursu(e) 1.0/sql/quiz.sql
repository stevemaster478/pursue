DROP DATABASE IF EXISTS Quiz;
CREATE DATABASE Quiz;
USE Quiz;

CREATE TABLE utente(
    username VARCHAR(30) PRIMARY KEY NOT NULL,
    email VARCHAR(30) NOT NULL,
    pass VARCHAR(30) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE corso(
    codice_corso INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    tipo VARCHAR(30) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE difficolta(
    codice_difficolta INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    diff VARCHAR(30) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE domanda (
  id_domanda int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  domanda varchar(50) NOT NULL,
  fk_corso int(11) NOT NULL,
  difficoltaDomanda int(11) NOT NULL,
  CONSTRAINT fk FOREIGN KEY (fk_corso) REFERENCES corso(codice_corso),
  CONSTRAINT fkD FOREIGN KEY (difficoltaDomanda) REFERENCES difficolta(codice_difficolta)
) ENGINE=InnoDB;

CREATE TABLE risposte(
    id_ris INT(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    num_domanda INT(11) NOT NULL,
    corretta TINYINT(1) NOT NULL,
    testo VARCHAR(400) NOT NULL,
    fk_corso int(11) NOT NULL,
    difficoltaDomanda int(11) NOT NULL,
    CONSTRAINT fkRis FOREIGN KEY (fk_corso) REFERENCES corso(codice_corso),
    CONSTRAINT fkdRis FOREIGN KEY (difficoltaDomanda) REFERENCES difficolta(codice_difficolta)
) ENGINE=InnoDB;

